"""
河川砂防RAPTOR Tree可視化スクリプト
NetworkXとMatplotlibを使用してツリー構造を可視化

kasensabo_raptor_tree.pklから階層構造を読み込み、
視覚化してPNG/PDFとして保存します。
"""

import os
import sys
import pickle
import networkx as nx
import matplotlib.pyplot as plt
import matplotlib
from pathlib import Path
from typing import Dict, List, Tuple, Any
import numpy as np
from datetime import datetime
import re
from collections import Counter

# 日本語フォント設定
matplotlib.rcParams['font.family'] = ['Yu Gothic', 'Meiryo', 'DejaVu Sans']
matplotlib.rcParams['axes.unicode_minus'] = False

# 河川砂防語彙をインポート
try:
    from kasensabo_vocab import (
        filter_kasensabo_keywords,
        is_kasensabo_keyword,
        is_stop_word,
        translate_keyword,
        get_priority_keywords_by_depth,
    )
except ImportError:
    print("⚠️ kasensabo_vocab.pyが見つかりません。基本機能のみ使用します")
    def is_stop_word(word): return False
    def is_kasensabo_keyword(word): return True
    def translate_keyword(word): return word
    def filter_kasensabo_keywords(keywords, depth=0): return keywords
    def get_priority_keywords_by_depth(depth): return set()


def extract_keywords_from_text(text: str, top_n: int = 5, depth: int = 0) -> List[str]:
    """
    テキストから重要キーワードを抽出（河川砂防ドメイン特化）
    
    深さに応じて優先キーワードカテゴリを変更：
    - depth=0: 全カテゴリ（リーフ）
    - depth=1: 各分野の主要施設・概念
    - depth=2: 技術・手法
    - depth>=3: 体系・大分類
    """
    if not text or len(text.strip()) == 0:
        return []
    
    keywords = []
    
    # 1. 深さに応じた優先キーワードを取得
    priority_keywords = get_priority_keywords_by_depth(depth)
    
    # 優先キーワードから検索
    for keyword in priority_keywords:
        if keyword in text and not is_stop_word(keyword):
            keywords.append(keyword)
            if len(keywords) >= top_n:
                return keywords
    
    # 2. 一般的な単語抽出（簡易版）
    words = re.findall(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]+', text)
    word_counts = Counter([w for w in words if len(w) >= 2 and not is_stop_word(w)])
    
    for word, count in word_counts.most_common(top_n * 2):
        if word not in keywords and (is_kasensabo_keyword(word) or len(word) >= 3):
            keywords.append(word)
            if len(keywords) >= top_n:
                break
    
    return keywords[:top_n]


def load_raptor_tree(pkl_file: str) -> Dict[str, Any]:
    """
    kasensabo_raptor.pyで保存したツリーを読み込み
    
    Returns:
        tree_data: {
            'nodes': Dict[str, RAPTORNode],
            'root_nodes': List[str],
            'tree_depth': int,
            'node_id_map': List[str],
            'embedding_dim': int,
        }
    """
    print(f"\n📂 RAPTOR Tree読み込み中: {pkl_file}")
    
    if not os.path.exists(pkl_file):
        raise FileNotFoundError(f"ツリーファイルが見つかりません: {pkl_file}")
    
    with open(pkl_file, 'rb') as f:
        tree_data = pickle.load(f)
    
    nodes = tree_data.get('nodes', {})
    tree_depth = tree_data.get('tree_depth', 0)
    root_nodes = tree_data.get('root_nodes', [])
    
    print(f"✅ ツリー読み込み完了")
    print(f"   ノード数: {len(nodes)}")
    print(f"   ツリー深さ: {tree_depth}")
    print(f"   ルートノード数: {len(root_nodes)}")
    
    return tree_data


def build_graph_from_tree(tree_data: Dict[str, Any]) -> Tuple[nx.DiGraph, Dict]:
    """
    RAPTORツリーからNetworkXグラフを構築
    
    Args:
        tree_data: kasensabo_raptor.pyで保存したツリーデータ
    
    Returns:
        (G, node_info): NetworkXグラフとノード情報の辞書
    """
    nodes = tree_data['nodes']
    root_nodes = tree_data['root_nodes']
    tree_depth = tree_data['tree_depth']
    
    G = nx.DiGraph()
    node_info = {}
    
    print("\n🔨 NetworkXグラフ構築中...")
    
    # 全ノードを追加
    for node_id, node in nodes.items():
        # キーワード抽出
        keywords = extract_keywords_from_text(node.text, top_n=3, depth=node.depth)
        
        # ラベル作成（英語・日本語）
        if len(keywords) >= 2:
            label_ja = f"{keywords[0]}\n{keywords[1]}"
            label_en = f"{translate_keyword(keywords[0])}\n{translate_keyword(keywords[1])}"
        elif len(keywords) == 1:
            label_ja = keywords[0]
            label_en = translate_keyword(keywords[0])
        else:
            label_ja = node_id[:10]
            label_en = node_id[:10]
        
        # ノードタイプ
        if node.depth == 0:
            node_type = 'leaf'
        else:
            node_type = 'internal'
        
        # レイヤー（表示用、深さを反転）
        layer = tree_depth - node.depth
        
        node_info[node_id] = {
            'label': label_en,
            'label_ja': label_ja,
            'layer': layer,
            'depth': node.depth,
            'text': node.text[:100],
            'keywords': keywords,
            'node_type': node_type,
        }
        
        G.add_node(node_id, **node_info[node_id])
    
    # エッジを追加（親子関係）
    for node_id, node in nodes.items():
        # 親→子のエッジ
        for child_id in node.children:
            if child_id in nodes:
                G.add_edge(node_id, child_id)
    
    print(f"✅ グラフ構築完了")
    print(f"   ノード数: {G.number_of_nodes()}")
    print(f"   エッジ数: {G.number_of_edges()}")
    
    return G, node_info


def visualize_tree(
    G: nx.DiGraph,
    node_info: Dict,
    output_path: str,
    title: str = "河川砂防技術基準 RAPTOR Tree",
    use_japanese: bool = True,
    figsize: Tuple[int, int] = (20, 12),
    dpi: int = 150,
):
    """
    RAPTORツリーを可視化
    
    Args:
        G: NetworkXグラフ
        node_info: ノード情報の辞書
        output_path: 出力ファイルパス
        title: グラフタイトル
        use_japanese: 日本語ラベルを使用するか
        figsize: 図のサイズ
        dpi: 解像度
    """
    print(f"\n🎨 ツリー可視化中...")
    
    fig, ax = plt.subplots(figsize=figsize, dpi=dpi)
    
    # 階層的レイアウト
    try:
        # pygraphvizが利用可能な場合はGraphvizレイアウト
        pos = nx.nx_agraph.graphviz_layout(G, prog='dot')
    except (ImportError, AttributeError):
        # pygraphvizが利用できない場合は代替レイアウト
        print("⚠️ pygraphvizが利用できません。代替レイアウトを使用します")
        # 階層レベルごとにY座標を設定
        pos = {}
        layers = {}
        for node in G.nodes():
            depth = node_info[node]['depth']
            if depth not in layers:
                layers[depth] = []
            layers[depth].append(node)
        
        # 各層のノードを配置
        for depth, nodes in layers.items():
            y = -depth * 200  # 上から下へ
            for i, node in enumerate(nodes):
                x = (i - len(nodes) / 2) * 300  # 中央揃え
                pos[node] = (x, y)
    
    # ノードを階層ごとに色分け
    node_colors = []
    node_sizes = []
    
    for node_id in G.nodes():
        depth = node_info[node_id]['depth']
        node_type = node_info[node_id]['node_type']
        
        # 深さに応じた色
        if depth == 0:
            color = '#90EE90'  # ライトグリーン（リーフ）
            size = 300
        elif depth == 1:
            color = '#87CEEB'  # スカイブルー
            size = 500
        elif depth == 2:
            color = '#FFB6C1'  # ライトピンク
            size = 700
        else:
            color = '#FFD700'  # ゴールド（ルート）
            size = 900
        
        node_colors.append(color)
        node_sizes.append(size)
    
    # ノード描画
    nx.draw_networkx_nodes(
        G, pos,
        node_color=node_colors,
        node_size=node_sizes,
        alpha=0.8,
        ax=ax
    )
    
    # エッジ描画
    nx.draw_networkx_edges(
        G, pos,
        edge_color='gray',
        alpha=0.5,
        arrows=True,
        arrowsize=15,
        ax=ax
    )
    
    # ラベル描画
    labels = {}
    for node_id in G.nodes():
        if use_japanese:
            labels[node_id] = node_info[node_id]['label_ja']
        else:
            labels[node_id] = node_info[node_id]['label']
    
    nx.draw_networkx_labels(
        G, pos,
        labels=labels,
        font_size=8,
        font_family='Yu Gothic' if use_japanese else 'DejaVu Sans',
        ax=ax
    )
    
    # タイトルと凡例
    ax.set_title(title, fontsize=16, fontweight='bold', pad=20)
    ax.axis('off')
    
    # 凡例
    from matplotlib.patches import Patch
    legend_elements = [
        Patch(facecolor='#FFD700', label=f'ルート層 (depth={max(n["depth"] for n in node_info.values())})'),
        Patch(facecolor='#FFB6C1', label='要約層 2'),
        Patch(facecolor='#87CEEB', label='要約層 1'),
        Patch(facecolor='#90EE90', label='リーフ層 (depth=0)'),
    ]
    ax.legend(handles=legend_elements, loc='upper right', fontsize=10)
    
    plt.tight_layout()
    
    # 保存
    plt.savefig(output_path, dpi=dpi, bbox_inches='tight')
    print(f"💾 可視化を保存: {output_path}")
    
    plt.close()


def visualize_tree_by_depth(
    G: nx.DiGraph,
    node_info: Dict,
    output_dir: str,
    base_filename: str = "kasensabo_tree",
    use_japanese: bool = True,
):
    """
    深さごとにツリーを可視化
    
    Args:
        G: NetworkXグラフ
        node_info: ノード情報の辞書
        output_dir: 出力ディレクトリ
        base_filename: ベースファイル名
        use_japanese: 日本語ラベルを使用するか
    """
    # 最大深さを取得
    max_depth = max(node_info[n]['depth'] for n in G.nodes())
    
    print(f"\n📊 深さごとの可視化 (depth 0 to {max_depth})")
    
    for depth in range(max_depth + 1):
        # 特定の深さのノードのみ抽出
        nodes_at_depth = [n for n in G.nodes() if node_info[n]['depth'] == depth]
        subgraph = G.subgraph(nodes_at_depth)
        
        if len(subgraph.nodes()) == 0:
            continue
        
        output_path = os.path.join(output_dir, f"{base_filename}_depth{depth}.png")
        title = f"河川砂防技術基準 RAPTOR Tree - Depth {depth} ({len(nodes_at_depth)} nodes)"
        
        visualize_tree(
            subgraph,
            node_info,
            output_path,
            title=title,
            use_japanese=use_japanese,
            figsize=(16, 10),
        )


def main():
    """メイン処理"""
    print("=" * 60)
    print("河川砂防RAPTOR Tree 可視化")
    print("=" * 60)
    
    # ファイルパス
    script_dir = Path(__file__).parent
    tree_file = script_dir / "kasensabo_raptor_tree.pkl"
    output_dir = script_dir / "visualizations"
    output_dir.mkdir(exist_ok=True)
    
    # ツリー読み込み
    tree_data = load_raptor_tree(str(tree_file))
    
    # グラフ構築
    G, node_info = build_graph_from_tree(tree_data)
    
    # 全体の可視化（日本語）
    output_path_ja = output_dir / "kasensabo_tree_full_ja.png"
    visualize_tree(
        G, node_info,
        str(output_path_ja),
        title="河川砂防技術基準 RAPTOR Tree（全体）",
        use_japanese=True,
        figsize=(24, 16),
        dpi=150,
    )
    
    # 全体の可視化（英語）
    output_path_en = output_dir / "kasensabo_tree_full_en.png"
    visualize_tree(
        G, node_info,
        str(output_path_en),
        title="River and Sabo Technical Standards RAPTOR Tree (Full)",
        use_japanese=False,
        figsize=(24, 16),
        dpi=150,
    )
    
    # 深さごとの可視化
    visualize_tree_by_depth(
        G, node_info,
        str(output_dir),
        base_filename="kasensabo_tree",
        use_japanese=True,
    )
    
    print(f"\n{'='*60}")
    print("✅ 可視化完了")
    print(f"   出力ディレクトリ: {output_dir}")
    print(f"{'='*60}\n")


if __name__ == "__main__":
    # pygraphvizの確認
    try:
        import pygraphviz
        print("✅ pygraphviz が利用可能")
    except ImportError:
        print("⚠️ pygraphviz がインストールされていません")
        print("   階層的レイアウトにはpygraphvizが必要です")
        print("   代替レイアウトを使用します")
    
    main()
