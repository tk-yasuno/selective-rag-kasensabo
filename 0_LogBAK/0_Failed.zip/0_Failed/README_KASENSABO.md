# 河川砂防技術基準 RAPTOR システム

河川砂防技術基準の知識ベースから階層的要約ツリー（RAPTOR）を構築し、可視化するMVPシステムです。

## 📋 概要

このシステムは以下の機能を提供します：

- **知識ベースの読み込み**: 8つのMarkdownファイルから河川砂防技術基準を読み込み
- **RAPTOR ツリー構築**: 階層的クラスタリングによる要約ツリーの自動生成
- **ベクトル検索**: FAISSを使用した高速な類似度検索
- **ツリー可視化**: NetworkXとMatplotlibによる階層構造の視覚化

## 🎯 特徴

- ✅ **テキストのみ**: 画像処理なし、テキストエンベディングのみで動作
- ✅ **日本語対応**: 多言語埋め込みモデル（multilingual-e5-large）を使用
- ✅ **ドメイン特化**: 河川砂防技術基準の専門用語辞書を搭載
- ✅ **スケーラブル**: 大規模な文書セットにも対応可能

## 📁 ファイル構成

```
kasensabo-raptor/
├── kasensabo_raptor.py           # RAPTOR本体の実装
├── kasensabo_vocab.py            # 河川砂防ドメイン語彙辞書
├── visualize_kasensabo_tree.py   # ツリー可視化スクリプト
├── run_kasensabo_raptor.py       # メインスクリプト
├── README_KASENSABO.md           # このファイル
├── data/
│   └── kasensabo_knowledge_base/ # 知識ベース（8つのMarkdownファイル）
│       ├── 00_training_overview_2025.md
│       ├── 01_training_chousa_2025.md
│       ├── 02_training_keikaku_kihon_2025.md
│       ├── 03_training_keikaku_shisetsu_2025.md
│       ├── 04_training_sekkei_2025.md
│       ├── 05_training_ijikanri_kasen_2025.md
│       ├── 06_training_ijikanri_dam_2025.md
│       └── 07_training_ijikanri_sabo_2025.md
└── visualizations/               # 可視化結果の出力先（自動作成）
```

## 🚀 使い方

### 1. 環境準備

必要なパッケージをインストール：

```bash
pip install torch sentence-transformers faiss-cpu langchain langchain-huggingface scikit-learn networkx matplotlib pykakasi
```

### 2. RAPTORツリー構築

知識ベースからRAPTORツリーを構築します：

```bash
python run_kasensabo_raptor.py --build
```

オプション：
- `--max-depth 3`: ツリーの最大深さ（デフォルト: 3）
- `--max-clusters 8`: 各層の最大クラスタ数（デフォルト: 8）

実行後、`kasensabo_raptor_tree.pkl`が生成されます。

### 3. 検索実行

構築したツリーに対してクエリを実行：

```bash
python run_kasensabo_raptor.py --query "堤防の維持管理"
```

オプション：
- `--top-k 5`: 返す結果の数（デフォルト: 5）

### 4. ツリー可視化

ツリー構造を視覚化：

```bash
python run_kasensabo_raptor.py --visualize
```

可視化結果は`visualizations/`ディレクトリに保存されます：
- `kasensabo_tree_full_ja.png`: 全体ツリー（日本語ラベル）
- `kasensabo_tree_full_en.png`: 全体ツリー（英語ラベル）
- `kasensabo_tree_depth0.png`: 深さ0のノード
- `kasensabo_tree_depth1.png`: 深さ1のノード
- など

### 5. 一括実行

構築と可視化を一度に実行：

```bash
python run_kasensabo_raptor.py --all
```

## 📊 システムアーキテクチャ

### RAPTORツリー構築プロセス

```
1. 文書読み込み
   └─> 8つのMarkdownファイルを読み込み

2. チャンク化
   └─> RecursiveCharacterTextSplitterで分割
       (chunk_size=1000, overlap=200)

3. リーフノード作成（depth=0）
   └─> 各チャンクを埋め込みベクトルに変換
       (multilingual-e5-large)

4. 階層的クラスタリング（depth=1,2,3...）
   └─> k-meansでクラスタリング
   └─> 各クラスタから要約ノードを作成
   └─> 繰り返し（収束まで）

5. FAISSインデックス構築
   └─> 全ノードの埋め込みをインデックス化
```

### 主要コンポーネント

#### 1. `KasensaboRAPTOR` クラス

主要メソッド：
- `load_documents_from_directory()`: Markdown読み込み
- `build_raptor_tree()`: ツリー構築
- `query()`: 類似度検索
- `save_tree()` / `load_tree()`: ツリーの保存・読み込み

#### 2. `kasensabo_vocab.py`

河川砂防技術基準の専門用語辞書：
- `KASENSABO_DOMAIN_KEYWORDS`: 専門用語セット（200語以上）
- `KASENSABO_TRANSLATION_DICT`: 日英翻訳辞書
- `filter_kasensabo_keywords()`: キーワードフィルタリング
- `translate_keyword()`: 日本語→英語翻訳

主要カテゴリ：
- 河川関連: 堤防、護岸、水制、樋門、樋管など
- 砂防関連: 砂防堰堤、床固工、山腹工など
- ダム関連: 重力式ダム、洪水吐き、減勢工など
- 維持管理: 点検、健全度評価、損傷、補修など

#### 3. `visualize_kasensabo_tree.py`

可視化機能：
- NetworkXでグラフ構築
- Graphvizによる階層レイアウト
- 深さごとの色分け表示
- 日本語・英語ラベル対応

## 🔍 使用例

### 例1: 堤防の維持管理に関する検索

```bash
python run_kasensabo_raptor.py --query "堤防の点検と維持管理" --top-k 5
```

### 例2: 砂防堰堤の設計に関する検索

```bash
python run_kasensabo_raptor.py --query "砂防堰堤の構造設計" --top-k 5
```

### 例3: ダムの健全度評価に関する検索

```bash
python run_kasensabo_raptor.py --query "ダムの健全度評価と点検" --top-k 5
```

## 📈 性能

### テスト環境

- CPU: Intel Core i7
- RAM: 16GB
- GPU: NVIDIA RTX 3060（CUDA対応）

### 処理時間（目安）

- ツリー構築: 約3-5分（8文書、1000チャンク程度）
- 検索: 数秒以内
- 可視化: 約30秒

### メモリ使用量

- 埋め込みモデル: 約2GB
- ツリーデータ: 約500MB（1000ノード）
- FAISSインデックス: 約100MB

## 🛠️ カスタマイズ

### パラメータ調整

`kasensabo_raptor.py`の初期化パラメータ：

```python
raptor = KasensaboRAPTOR(
    embedding_model_name="intfloat/multilingual-e5-large",  # 埋め込みモデル
    max_clusters_per_layer=8,     # 各層の最大クラスタ数
    min_cluster_size=3,            # クラスタの最小サイズ
    chunk_size=1000,               # チャンクサイズ
    chunk_overlap=200,             # チャンクオーバーラップ
)
```

### 埋め込みモデルの変更

他の多言語モデルも使用可能：
- `intfloat/multilingual-e5-base` (軽量版)
- `sentence-transformers/paraphrase-multilingual-mpnet-base-v2`
- `cl-tohoku/bert-base-japanese-v3` (日本語特化)

## 📝 技術詳細

### RAPTORアルゴリズム

本実装は以下の論文に基づいています：

> RAPTOR: Recursive Abstractive Processing for Tree-Organized Retrieval
> Sarthi et al., 2024

主要な改良点：
- 多言語埋め込みモデルの使用
- ドメイン特化語彙の統合
- 視覚的可視化機能

### テキスト処理

- **分割**: `RecursiveCharacterTextSplitter`で意味単位を保持
- **埋め込み**: `multilingual-e5-large`でL2正規化済みベクトル
- **クラスタリング**: k-meansで階層的にグループ化
- **要約**: 各クラスタの代表テキストを結合（将来的にLLM要約も可能）

### 検索方式

1. クエリを埋め込みベクトルに変換
2. FAISSで高速な類似度検索（Inner Product）
3. スコア順にソート
4. 上位K件を返す

## 🐛 トラブルシューティング

### エラー: "No module named 'pygraphviz'"

可視化にはpygraphvizが必要です（オプション）：

```bash
# Windows
# Graphvizをインストール: https://graphviz.org/download/
pip install pygraphviz

# Linux/Mac
sudo apt-get install graphviz graphviz-dev  # Debian/Ubuntu
brew install graphviz  # macOS
pip install pygraphviz
```

pygraphvizなしでも実行可能ですが、レイアウトが制限されます。

### メモリ不足エラー

チャンクサイズやバッチサイズを調整：

```python
raptor = KasensaboRAPTOR(
    chunk_size=500,        # 小さく
    max_clusters_per_layer=5,  # 少なく
)
```

### CUDA/GPU関連エラー

CPUモードで実行：

```bash
export CUDA_VISIBLE_DEVICES=""  # Linux/Mac
set CUDA_VISIBLE_DEVICES=  # Windows CMD
```

## 📚 参考資料

- [RAPTOR論文](https://arxiv.org/abs/2401.18059)
- [Sentence Transformers](https://www.sbert.net/)
- [FAISS](https://github.com/facebookresearch/faiss)
- [LangChain](https://www.langchain.com/)

## 📄 ライセンス

このプロジェクトはMITライセンスの下で公開されています。

## 🤝 貢献

バグ報告や機能提案は歓迎します。

---

**作成日**: 2025年11月6日  
**バージョン**: 1.0.0
