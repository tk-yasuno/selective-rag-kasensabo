"""
河川砂防技術基準 RAPTOR システム
Text-Only RAPTOR for River and Sabo Technical Standards

テキストエンベディングのみを使用したRAPTOR実装
画像処理を含まず、Markdownテキストから階層的要約ツリーを構築
"""

import os
import sys
import torch
import numpy as np
import faiss
from pathlib import Path
from typing import List, Dict, Tuple, Optional, Any
from dataclasses import dataclass
import pickle
import json
from collections import defaultdict

# LangChain imports
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from sentence_transformers import SentenceTransformer

# 河川砂防語彙をインポート
from kasensabo_vocab import (
    KASENSABO_DOMAIN_KEYWORDS,
    KASENSABO_TRANSLATION_DICT,
    filter_kasensabo_keywords,
    is_kasensabo_keyword,
    translate_keyword,
)


@dataclass
class RAPTORNode:
    """RAPTOR ツリーのノード"""
    node_id: str
    text: str
    embedding: np.ndarray
    children: List[str] = None  # 子ノードのIDリスト
    parent: Optional[str] = None  # 親ノードのID
    depth: int = 0  # ツリーの深さ（0=リーフノード）
    metadata: Dict = None
    
    def __post_init__(self):
        if self.children is None:
            self.children = []
        if self.metadata is None:
            self.metadata = {}


class KasensaboRAPTOR:
    """
    河川砂防技術基準のためのRAPTORシステム
    
    特徴:
    - テキストのみ（画像処理なし）
    - 日本語対応の多言語埋め込みモデル
    - 階層的クラスタリングによる要約ツリー構築
    - FAISSを使用した高速ベクトル検索
    """
    
    def __init__(
        self,
        embedding_model_name: str = "sentence-transformers/paraphrase-multilingual-mpnet-base-v2",
        max_clusters_per_layer: int = 10,
        min_cluster_size: int = 3,
        chunk_size: int = 1000,
        chunk_overlap: int = 200,
        device: str = None,
    ):
        """
        Args:
            embedding_model_name: HuggingFaceの埋め込みモデル名
            max_clusters_per_layer: 各層の最大クラスタ数
            min_cluster_size: クラスタの最小サイズ
            chunk_size: テキストチャンクのサイズ
            chunk_overlap: チャンク間のオーバーラップ
            device: 'cuda' or 'cpu'
        """
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.max_clusters_per_layer = max_clusters_per_layer
        self.min_cluster_size = min_cluster_size
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        
        print(f"🚀 河川砂防RAPTOR システム初期化")
        print(f"   Device: {self.device}")
        print(f"   Embedding Model: {embedding_model_name}")
        
        # 埋め込みモデルの初期化
        self.embedding_model = SentenceTransformer(
            embedding_model_name,
            device=self.device
        )
        self.embedding_dim = self.embedding_model.get_sentence_embedding_dimension()
        print(f"   Embedding Dimension: {self.embedding_dim}")
        
        # テキストスプリッター
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            length_function=len,
            separators=["\n\n", "\n", "。", "、", " ", ""],
        )
        
        # RAPTORツリーの構造
        self.nodes: Dict[str, RAPTORNode] = {}  # node_id -> RAPTORNode
        self.tree_depth = 0
        self.root_nodes: List[str] = []  # 最上位ノードのIDリスト
        
        # FAISSインデックス
        self.index = None
        self.node_id_map: List[str] = []  # FAISSインデックスからnode_idへのマッピング
        
        print("✅ 初期化完了")
    
    def load_documents_from_directory(self, directory_path: str) -> List[Document]:
        """
        ディレクトリから全てのMarkdownファイルを読み込み
        
        Args:
            directory_path: Markdownファイルのディレクトリパス
        
        Returns:
            LangChain Documentのリスト
        """
        documents = []
        directory = Path(directory_path)
        
        print(f"📂 ディレクトリから文書を読み込み中: {directory}")
        
        # .mdファイルを検索
        md_files = sorted(directory.glob("*.md"))
        
        for md_file in md_files:
            print(f"   読み込み: {md_file.name}")
            with open(md_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            doc = Document(
                page_content=content,
                metadata={
                    "source": str(md_file),
                    "filename": md_file.name,
                }
            )
            documents.append(doc)
        
        print(f"✅ {len(documents)} 個の文書を読み込みました")
        return documents
    
    def create_chunks(self, documents: List[Document]) -> List[Document]:
        """
        文書をチャンクに分割
        
        Args:
            documents: 元の文書リスト
        
        Returns:
            チャンクされた文書リスト
        """
        print(f"📄 文書をチャンク化中...")
        chunks = []
        
        for doc in documents:
            doc_chunks = self.text_splitter.split_documents([doc])
            chunks.extend(doc_chunks)
        
        print(f"✅ {len(chunks)} 個のチャンクを作成しました")
        return chunks
    
    def embed_texts(self, texts: List[str], batch_size: int = 32) -> np.ndarray:
        """
        テキストを埋め込みベクトルに変換
        
        Args:
            texts: テキストのリスト
            batch_size: バッチサイズ
        
        Returns:
            埋め込みベクトルの配列 [num_texts, embedding_dim]
        """
        if not texts:
            return np.empty((0, self.embedding_dim))
        
        embeddings = self.embedding_model.encode(
            texts,
            batch_size=batch_size,
            show_progress_bar=True,
            convert_to_numpy=True,
            normalize_embeddings=True,  # L2正規化
        )
        
        return embeddings
    
    def build_raptor_tree(
        self,
        documents: List[Document],
        max_depth: int = 3,
        max_clusters: int = 8,
    ) -> Dict[str, RAPTORNode]:
        """
        RAPTOR階層ツリーを構築
        
        Args:
            documents: 文書のリスト
            max_depth: ツリーの最大深さ
            max_clusters: サブクラスタリングの最大クラスタ数
        
        Returns:
            構築されたツリー（ノードの辞書）
        """
        print(f"\n{'='*60}")
        print(f"🌲 RAPTOR ツリー構築開始")
        print(f"{'='*60}")
        
        # ステップ1: チャンク化
        chunks = self.create_chunks(documents)
        
        # ステップ2: リーフノード（depth=0）を作成
        print(f"\n📍 リーフノード作成中...")
        
        # バッチ処理のため、まずテキストを収集
        chunk_texts = [chunk.page_content for chunk in chunks]
        
        # 全チャンクを一度に埋め込み（バッチサイズ=64）
        print(f"   埋め込み生成中 ({len(chunk_texts)} チャンク)...")
        all_embeddings = self.embed_texts(chunk_texts, batch_size=64)
        
        # ノードを作成
        leaf_nodes = []
        for i, (chunk, embedding) in enumerate(zip(chunks, all_embeddings)):
            node_id = f"leaf_{i:04d}"
            
            node = RAPTORNode(
                node_id=node_id,
                text=chunk.page_content,
                embedding=embedding,
                depth=0,
                metadata=chunk.metadata,
            )
            self.nodes[node_id] = node
            leaf_nodes.append(node_id)
        
        print(f"✅ {len(leaf_nodes)} 個のリーフノードを作成")
        
        # ステップ3: 階層的にクラスタリングして要約ノードを作成
        # 階層1では、ドメイン知識に基づいた3つのカテゴリに分類
        current_layer_nodes = leaf_nodes
        current_depth = 1
        
        # 階層1専用: ドメイン知識ベースの分類
        if current_depth == 1 and len(current_layer_nodes) > 1:
            print(f"\n🔄 階層 {current_depth} を構築中（ドメイン知識ベース分類）...")
            print(f"   入力ノード数: {len(current_layer_nodes)}")
            
            # カテゴリ別にノードを分類
            category_clusters = self._classify_by_domain_knowledge(current_layer_nodes)
            
            print(f"   カテゴリ数: {len(category_clusters)}")
            for cat_name, node_list in category_clusters.items():
                print(f"      {cat_name}: {len(node_list)} ノード")
            
            # 各カテゴリから要約ノードを作成
            next_layer_nodes = []
            summary_texts = []
            valid_clusters = []
            category_metadata = []  # カテゴリ情報を保持
            
            for cat_name, cluster_node_ids in category_clusters.items():
                if len(cluster_node_ids) < self.min_cluster_size:
                    # クラスタが小さすぎる場合はスキップ
                    continue
                
                summary_text = self._create_summary(cluster_node_ids)
                summary_texts.append(summary_text)
                valid_clusters.append((cat_name, cluster_node_ids))
                category_metadata.append({
                    "category": cat_name,
                    "node_ids": cluster_node_ids,
                    "needs_subclustering": len(cluster_node_ids) >= 1000  # 1000ノード以上でサブクラスタリング
                })
            
            # 要約をバッチで埋め込み
            if summary_texts:
                print(f"   要約埋め込み生成中 ({len(summary_texts)} 要約)...")
                summary_embeddings = self.embed_texts(summary_texts, batch_size=32)
                
                # ノードを作成
                for (cat_name, cluster_node_ids), summary_text, summary_embedding, cat_meta in zip(
                    valid_clusters, summary_texts, summary_embeddings, category_metadata
                ):
                    summary_node_id = f"category_{cat_name}_d{current_depth}"
                    
                    summary_node = RAPTORNode(
                        node_id=summary_node_id,
                        text=summary_text,
                        embedding=summary_embedding,
                        children=cluster_node_ids,
                        depth=current_depth,
                        metadata={
                            "category": cat_name,
                            "cluster_size": len(cluster_node_ids),
                            "needs_subclustering": cat_meta["needs_subclustering"]
                        },
                    )
                    self.nodes[summary_node_id] = summary_node
                    
                    # 子ノードに親を設定
                    for child_id in cluster_node_ids:
                        self.nodes[child_id].parent = summary_node_id
                    
                    next_layer_nodes.append(summary_node_id)
            
            print(f"✅ 階層 {current_depth}: {len(next_layer_nodes)} 個のカテゴリノードを作成")
            
            # 次の階層に進む
            if len(next_layer_nodes) == 0:
                print(f"   ℹ️  これ以上の階層化は不要です（現在の階層をルートとして使用）")
            else:
                current_layer_nodes = next_layer_nodes
                current_depth += 1
                
                # 階層2: 大きなカテゴリをサブクラスタリング
                if current_depth == 2:
                    print(f"\n🔄 階層 {current_depth} を構築中（サブクラスタリング）...")
                    
                    next_layer_nodes = []
                    
                    for node_id in current_layer_nodes:
                        node = self.nodes[node_id]
                        category_name = node.metadata.get("category", "unknown")
                        needs_subclustering = node.metadata.get("needs_subclustering", False)
                        child_count = len(node.children)
                        
                        if needs_subclustering:
                            print(f"   {category_name}: {child_count} ノード → サブクラスタリング実行")
                            
                            # 子ノードをクラスタリング
                            clusters = self._cluster_nodes(
                                node.children,
                                current_depth,
                                max_clusters=max_clusters
                            )
                            
                            # 各サブクラスタから要約ノードを作成
                            summary_texts = []
                            valid_clusters = []
                            
                            for cluster_idx, cluster_node_ids in enumerate(clusters):
                                if len(cluster_node_ids) < self.min_cluster_size and len(clusters) > 1:
                                    continue
                                
                                summary_text = self._create_summary(cluster_node_ids)
                                summary_texts.append(summary_text)
                                valid_clusters.append((cluster_idx, cluster_node_ids))
                            
                            if summary_texts:
                                print(f"      要約埋め込み生成中 ({len(summary_texts)} サブクラスタ)...")
                                summary_embeddings = self.embed_texts(summary_texts, batch_size=32)
                                
                                for (cluster_idx, cluster_node_ids), summary_text, summary_embedding in zip(
                                    valid_clusters, summary_texts, summary_embeddings
                                ):
                                    summary_node_id = f"subcluster_{category_name}_{cluster_idx:04d}_d{current_depth}"
                                    
                                    summary_node = RAPTORNode(
                                        node_id=summary_node_id,
                                        text=summary_text,
                                        embedding=summary_embedding,
                                        children=cluster_node_ids,  # 参照のみ、親は変更しない
                                        depth=current_depth,
                                        metadata={
                                            "parent_category": category_name,
                                            "cluster_size": len(cluster_node_ids),
                                            "is_summary": True  # 要約ノードであることを明示
                                        },
                                    )
                                    self.nodes[summary_node_id] = summary_node
                                    
                                    # RAPTOR本来のアルゴリズム: リーフノードの親は変更しない
                                    # サブクラスタノードは要約として独立して存在
                                    # サブクラスタノードの親をカテゴリノードに設定
                                    summary_node.parent = node_id
                                    
                                    next_layer_nodes.append(summary_node_id)
                                
                                print(f"      ✅ {len(valid_clusters)} 個のサブクラスタノードを作成")
                        else:
                            print(f"   {category_name}: {child_count} ノード → サブクラスタリング不要（カテゴリノードをそのまま使用）")
                            # RAPTOR: カテゴリノード自体が要約として機能
                            # 次の階層ではこのカテゴリノードを使用
                            next_layer_nodes.append(node_id)
                    
                    print(f"✅ 階層 {current_depth}: {len(next_layer_nodes)} 個のノードを作成")
                    
                    if len(next_layer_nodes) == 0:
                        print(f"   ℹ️  これ以上の階層化は不要です")
                    else:
                        current_layer_nodes = next_layer_nodes
                        current_depth += 1
        
        # 階層3以降: 通常のクラスタリング評価
        while current_depth <= max_depth and len(current_layer_nodes) > 1:
            print(f"\n🔄 階層 {current_depth} を構築中...")
            print(f"   入力ノード数: {len(current_layer_nodes)}")
            
            # クラスタリング
            clusters = self._cluster_nodes(
                current_layer_nodes,
                current_depth=current_depth,
                max_clusters=max_clusters
            )
            print(f"   クラスタ数: {len(clusters)}")
            
            # 各クラスタから要約ノードを作成
            next_layer_nodes = []
            summary_texts = []
            valid_clusters = []
            
            # まず要約テキストを全て生成
            for cluster_idx, cluster_node_ids in enumerate(clusters):
                # 最終階層（クラスタ数が1）またはmin_cluster_size以上の場合のみ要約を作成
                # ただし、全てのクラスタが小さすぎる場合は最大のクラスタを採用
                if len(cluster_node_ids) < self.min_cluster_size and len(clusters) > 1:
                    # クラスタが小さすぎる場合はスキップ（複数クラスタがある場合のみ）
                    continue
                
                summary_text = self._create_summary(cluster_node_ids)
                summary_texts.append(summary_text)
                valid_clusters.append((cluster_idx, cluster_node_ids))
            
            # 要約をバッチで埋め込み
            if summary_texts:
                print(f"   要約埋め込み生成中 ({len(summary_texts)} 要約)...")
                summary_embeddings = self.embed_texts(summary_texts, batch_size=32)
                
                # ノードを作成
                for (cluster_idx, cluster_node_ids), summary_text, summary_embedding in zip(
                    valid_clusters, summary_texts, summary_embeddings
                ):
                    summary_node_id = f"summary_d{current_depth}_{cluster_idx:04d}"
                    
                    summary_node = RAPTORNode(
                        node_id=summary_node_id,
                        text=summary_text,
                        embedding=summary_embedding,
                        children=cluster_node_ids,
                        depth=current_depth,
                        metadata={"cluster_size": len(cluster_node_ids)},
                    )
                    self.nodes[summary_node_id] = summary_node
                    
                    # 子ノードに親を設定
                    for child_id in cluster_node_ids:
                        self.nodes[child_id].parent = summary_node_id
                    
                    next_layer_nodes.append(summary_node_id)
            
            print(f"✅ 階層 {current_depth}: {len(next_layer_nodes)} 個の要約ノードを作成")
            
            # 次の階層に進む
            if len(next_layer_nodes) == 0:
                # 要約ノードが作成されなかった場合、現在の階層をルートとして終了
                print(f"   ℹ️  これ以上の階層化は不要です（現在の階層をルートとして使用）")
                break
            
            current_layer_nodes = next_layer_nodes
            current_depth += 1
        
        # 最上位層をルートノードとして記録
        self.root_nodes = current_layer_nodes
        self.tree_depth = current_depth - 1
        
        print(f"\n{'='*60}")
        print(f"✅ RAPTOR ツリー構築完了")
        print(f"   総ノード数: {len(self.nodes)}")
        print(f"   ツリー深さ: {self.tree_depth}")
        print(f"   ルートノード数: {len(self.root_nodes)}")
        print(f"{'='*60}\n")
        
        return self.nodes
    
    def _cluster_nodes(
        self, 
        node_ids: List[str],
        current_depth: int = 1,
        max_clusters: int = 5
    ) -> List[List[str]]:
        """
        ノードをクラスタリング（k-means使用）
        Silhouette と Davies-Bouldin Index で最適なクラスタ数を評価
        
        raptor_eval.pyの実装を参考に、複数の評価指標を統合:
        - Silhouette Score: クラスタの凝集度と分離度 (高いほど良い)
        - Davies-Bouldin Index: クラスタ間類似度 (低いほど良い)
        - Combined戦略: 0.5:0.5の重みで統合
        
        Args:
            node_ids: クラスタリング対象のノードIDリスト
            current_depth: 現在の階層深さ（ログ用）
            max_clusters: 評価する最大クラスタ数
        
        Returns:
            クラスタのリスト（各クラスタはノードIDのリスト）
        """
        # 埋め込みベクトルを取得
        embeddings = np.array([self.nodes[nid].embedding for nid in node_ids])
        
        # クラスタ数の範囲を決定（2-max_clustersの範囲で評価）
        min_k = 2
        max_k = min(max_clusters, len(node_ids))  # len(node_ids) - 1 ではなく len(node_ids) を使用
        
        # ノード数が2未満の場合は1つのクラスタとして返す
        if len(node_ids) < min_k:
            return [node_ids]
        
        # max_kがmin_k未満の場合も1つのクラスタとして返す
        if max_k < min_k:
            return [node_ids]
        
        # 各クラスタ数で評価
        from sklearn.cluster import KMeans
        from sklearn.metrics import silhouette_score, davies_bouldin_score
        
        silhouette_scores = []
        dbi_scores = []
        labels_list = []
        
        print(f"      クラスタ数評価 (k={min_k}~{max_k}):")
        
        for k in range(min_k, max_k + 1):
            # ノード数とクラスタ数が同じ場合はスキップ（Silhouetteスコアが計算できない）
            if k >= len(node_ids):
                continue
            
            # k-meansクラスタリング
            kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
            labels = kmeans.fit_predict(embeddings)
            labels_list.append(labels)
            
            # Silhouette スコア（高いほど良い: -1 ~ 1）
            sil_score = silhouette_score(embeddings, labels)
            silhouette_scores.append(sil_score)
            
            # Davies-Bouldin Index（低いほど良い: 0 ~ ∞）
            dbi_score = davies_bouldin_score(embeddings, labels)
            dbi_scores.append(dbi_score)
            
            print(f"        k={k}: Sil={sil_score:.4f}, DBI={dbi_score:.4f}")
        
        # 有効な評価がない場合は1つのクラスタとして返す
        if len(silhouette_scores) == 0:
            return [node_ids]
        
        # Combined戦略: Silhouette (0.5) + DBI (0.5)
        # raptor_eval.pyのnormalize_scoresを参考に正規化
        sil_array = np.array(silhouette_scores)
        dbi_array = np.array(dbi_scores)
        
        # Silhouetteを正規化（大きい方が良い → 小さい方が良い形式に反転）
        sil_min, sil_max = np.min(sil_array), np.max(sil_array)
        if sil_max - sil_min > 1e-10:
            sil_norm = 1.0 - (sil_array - sil_min) / (sil_max - sil_min)
        else:
            sil_norm = np.zeros_like(sil_array)
        
        # DBIを正規化（小さい方が良い形式のまま）
        dbi_min, dbi_max = np.min(dbi_array), np.max(dbi_array)
        if dbi_max - dbi_min > 1e-10:
            dbi_norm = (dbi_array - dbi_min) / (dbi_max - dbi_min)
        else:
            dbi_norm = np.zeros_like(dbi_array)
        
        # 複合スコア: 両方とも小さいほど良い形式
        combined_scores = 0.5 * sil_norm + 0.5 * dbi_norm
        
        # 最小スコアを選択
        best_idx = np.argmin(combined_scores)
        best_k = min_k + best_idx
        best_labels = labels_list[best_idx]
        
        print(f"      → 最適k={best_k} (Sil={silhouette_scores[best_idx]:.4f}, DBI={dbi_scores[best_idx]:.4f}, Combined={combined_scores[best_idx]:.4f})")
        
        # 最適なクラスタでグループ化
        clusters = defaultdict(list)
        for node_id, label in zip(node_ids, best_labels):
            clusters[label].append(node_id)
        
        return list(clusters.values())
    
    def _create_summary(self, node_ids: List[str]) -> str:
        """
        複数ノードから要約テキストを生成
        
        現在は単純な結合を使用。
        将来的にはLLMによる要約に置き換え可能。
        
        Args:
            node_ids: 要約対象のノードIDリスト
        
        Returns:
            要約テキスト
        """
        # ノードのテキストを収集
        texts = [self.nodes[nid].text for nid in node_ids]
        
        # 簡易要約: 各テキストの最初の200文字を結合
        summaries = []
        for text in texts:
            # 最初の段落または200文字
            first_para = text.split('\n\n')[0]
            summary = first_para[:200] if len(first_para) > 200 else first_para
            summaries.append(summary)
        
        # 全体の要約（重複を避けるため最大1000文字）
        combined = "\n\n".join(summaries)
        if len(combined) > 1000:
            combined = combined[:1000] + "..."
        
        return combined
    
    def _classify_by_domain_knowledge(
        self, node_ids: List[str]
    ) -> Dict[str, List[str]]:
        """
        ドメイン知識に基づいてノードを5つのカテゴリに分類する。
        
        分類規則:
        - 計画系 (planning): ファイル名に "keikaku" を含む
        - 設計系 (design): ファイル名に "sekkei" を含む
        - 維持管理系 (maintenance): ファイル名に "ijikanri" を含む
        - 概要 (overview): ファイル名に "overview" を含む
        - 調査 (chousa): ファイル名に "chousa" を含む
        
        Args:
            node_ids: 分類対象のノードIDリスト
            
        Returns:
            カテゴリ名をキー、ノードIDリストを値とする辞書
        """
        categories = {
            "planning": [],     # 計画系
            "design": [],       # 設計系
            "maintenance": [],  # 維持管理系
            "overview": [],     # 概要
            "chousa": []        # 調査
        }
        
        for node_id in node_ids:
            node = self.nodes[node_id]
            source_file = node.metadata.get("source", "")
            
            # ファイル名から分類を判定（優先順位順）
            if "keikaku" in source_file:
                categories["planning"].append(node_id)
            elif "sekkei" in source_file:
                categories["design"].append(node_id)
            elif "ijikanri" in source_file:
                categories["maintenance"].append(node_id)
            elif "overview" in source_file:
                categories["overview"].append(node_id)
            elif "chousa" in source_file:
                categories["chousa"].append(node_id)
        
        # 空のカテゴリは除外
        categories = {k: v for k, v in categories.items() if len(v) > 0}
        
        return categories
    
    def build_faiss_index(self):
        """
        全ノードからFAISSインデックスを構築
        """
        print(f"\n🔍 FAISSインデックス構築中...")
        
        # 全ノードの埋め込みを収集
        node_ids = list(self.nodes.keys())
        embeddings = np.array([self.nodes[nid].embedding for nid in node_ids])
        
        # FAISSインデックスを作成
        self.index = faiss.IndexFlatIP(self.embedding_dim)  # Inner Product（コサイン類似度）
        self.index.add(embeddings.astype('float32'))
        
        self.node_id_map = node_ids
        
        print(f"✅ FAISSインデックス構築完了: {len(node_ids)} ノード")
    
    def query(
        self,
        query_text: str,
        top_k: int = 5,
        depth_filter: Optional[int] = None,
    ) -> List[Tuple[str, float, RAPTORNode]]:
        """
        クエリに対して類似ノードを検索
        
        Args:
            query_text: 検索クエリ
            top_k: 返す結果の数
            depth_filter: 特定の深さのノードのみを検索（Noneの場合は全深さ）
        
        Returns:
            (node_id, score, node) のタプルのリスト
        """
        # クエリを埋め込み
        query_embedding = self.embed_texts([query_text])[0]
        
        # FAISSで検索
        scores, indices = self.index.search(
            query_embedding.reshape(1, -1).astype('float32'),
            min(top_k * 3, len(self.node_id_map))  # 余分に取得してフィルタリング
        )
        
        # 結果を整形
        results = []
        for score, idx in zip(scores[0], indices[0]):
            node_id = self.node_id_map[idx]
            node = self.nodes[node_id]
            
            # 深さフィルタ
            if depth_filter is not None and node.depth != depth_filter:
                continue
            
            results.append((node_id, float(score), node))
            
            if len(results) >= top_k:
                break
        
        return results
    
    def save_tree(self, filepath: str):
        """
        RAPTORツリーをファイルに保存
        
        Args:
            filepath: 保存先のファイルパス
        """
        save_data = {
            'nodes': self.nodes,
            'root_nodes': self.root_nodes,
            'tree_depth': self.tree_depth,
            'node_id_map': self.node_id_map,
            'embedding_dim': self.embedding_dim,
        }
        
        with open(filepath, 'wb') as f:
            pickle.dump(save_data, f)
        
        print(f"💾 RAPTORツリーを保存: {filepath}")
        print(f"   ノード数: {len(self.nodes)}")
        print(f"   ツリー深さ: {self.tree_depth}")
    
    def load_tree(self, filepath: str):
        """
        RAPTORツリーをファイルから読み込み
        
        Args:
            filepath: 読み込むファイルパス
        """
        with open(filepath, 'rb') as f:
            save_data = pickle.load(f)
        
        self.nodes = save_data['nodes']
        self.root_nodes = save_data['root_nodes']
        self.tree_depth = save_data['tree_depth']
        self.node_id_map = save_data['node_id_map']
        
        print(f"📂 RAPTORツリーを読み込み: {filepath}")
        print(f"   ノード数: {len(self.nodes)}")
        print(f"   ツリー深さ: {self.tree_depth}")
        
        # FAISSインデックスを再構築
        self.build_faiss_index()
    
    def get_tree_statistics(self) -> Dict[str, Any]:
        """
        ツリーの統計情報を取得
        
        Returns:
            統計情報の辞書
        """
        depth_counts = defaultdict(int)
        for node in self.nodes.values():
            depth_counts[node.depth] += 1
        
        return {
            'total_nodes': len(self.nodes),
            'tree_depth': self.tree_depth,
            'root_nodes_count': len(self.root_nodes),
            'nodes_per_depth': dict(depth_counts),
            'leaf_nodes_count': depth_counts[0],
        }


if __name__ == "__main__":
    # 使用例
    print("河川砂防RAPTOR システム")
    print("=" * 60)
    
    # データディレクトリ
    data_dir = Path(__file__).parent / "data" / "kasensabo_knowledge_base"
    
    # RAPTORシステムを初期化
    raptor = KasensaboRAPTOR(
        embedding_model_name="intfloat/multilingual-e5-large",
        max_clusters_per_layer=8,
        min_cluster_size=3,
        chunk_size=1000,
        chunk_overlap=200,
    )
    
    # 文書を読み込み
    documents = raptor.load_documents_from_directory(str(data_dir))
    
    # RAPTORツリーを構築
    raptor.build_raptor_tree(documents, max_depth=3)
    
    # FAISSインデックスを構築
    raptor.build_faiss_index()
    
    # 統計情報を表示
    stats = raptor.get_tree_statistics()
    print(f"\n📊 ツリー統計:")
    for key, value in stats.items():
        print(f"   {key}: {value}")
    
    # ツリーを保存
    output_path = Path(__file__).parent / "kasensabo_raptor_tree.pkl"
    raptor.save_tree(str(output_path))
    
    print("\n✅ 完了")
