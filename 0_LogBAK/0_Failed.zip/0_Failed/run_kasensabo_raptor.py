"""
河川砂防技術基準 RAPTOR システム - メインスクリプト
RAPTORツリーの構築、検索、可視化を実行

使用方法:
    python run_kasensabo_raptor.py --build       # ツリー構築
    python run_kasensabo_raptor.py --query "質問" # 検索
    python run_kasensabo_raptor.py --visualize   # 可視化
    python run_kasensabo_raptor.py --all         # 全て実行
"""

import argparse
import sys
from pathlib import Path
from datetime import datetime

# 河川砂防RAPTORをインポート
from kasensabo_raptor import KasensaboRAPTOR


def build_tree(
    data_dir: Path,
    output_path: Path,
    max_depth: int = 3,
    max_clusters: int = 8,
):
    """
    RAPTORツリーを構築して保存
    
    Args:
        data_dir: 知識ベースのディレクトリパス
        output_path: 出力ファイルパス
        max_depth: ツリーの最大深さ
        max_clusters: 各層の最大クラスタ数
    """
    print("\n" + "=" * 70)
    print("🌲 RAPTOR ツリー構築")
    print("=" * 70)
    
    # RAPTORシステムを初期化
    raptor = KasensaboRAPTOR(
        embedding_model_name="sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2",  # 軽量モデル
        max_clusters_per_layer=max_clusters,
        min_cluster_size=3,
        chunk_size=1000,
        chunk_overlap=200,
    )
    
    # 文書を読み込み
    print(f"\n📂 知識ベース読み込み: {data_dir}")
    documents = raptor.load_documents_from_directory(str(data_dir))
    
    if len(documents) == 0:
        print("❌ エラー: 文書が見つかりません")
        return None
    
    # RAPTORツリーを構築
    print(f"\n🔨 ツリー構築開始 (max_depth={max_depth}, max_clusters={max_clusters})")
    start_time = datetime.now()
    
    raptor.build_raptor_tree(documents, max_depth=max_depth)
    
    elapsed = (datetime.now() - start_time).total_seconds()
    print(f"\n⏱️ 構築時間: {elapsed:.2f} 秒")
    
    # FAISSインデックスを構築
    raptor.build_faiss_index()
    
    # 統計情報を表示
    stats = raptor.get_tree_statistics()
    print(f"\n📊 ツリー統計:")
    for key, value in stats.items():
        print(f"   {key}: {value}")
    
    # ツリーを保存
    raptor.save_tree(str(output_path))
    
    print(f"\n✅ ツリー構築完了")
    print("=" * 70)
    
    return raptor


def query_tree(
    tree_path: Path,
    query_text: str,
    top_k: int = 5,
):
    """
    RAPTORツリーに対してクエリを実行
    
    Args:
        tree_path: ツリーファイルのパス
        query_text: 検索クエリ
        top_k: 返す結果の数
    """
    print("\n" + "=" * 70)
    print("🔍 RAPTOR クエリ実行")
    print("=" * 70)
    
    # RAPTORシステムを初期化
    raptor = KasensaboRAPTOR()
    
    # ツリーを読み込み
    print(f"\n📂 ツリー読み込み: {tree_path}")
    raptor.load_tree(str(tree_path))
    
    # クエリ実行
    print(f"\n🔎 クエリ: {query_text}")
    print(f"   Top-K: {top_k}")
    
    results = raptor.query(query_text, top_k=top_k)
    
    # 結果を表示
    print(f"\n📄 検索結果 ({len(results)} 件):")
    print("-" * 70)
    
    for i, (node_id, score, node) in enumerate(results, 1):
        print(f"\n{i}. Node: {node_id}")
        print(f"   Depth: {node.depth}")
        print(f"   Score: {score:.4f}")
        print(f"   Text Preview: {node.text[:200]}...")
        if node.metadata:
            print(f"   Metadata: {node.metadata}")
    
    print("\n" + "=" * 70)
    
    return results


def visualize_tree(tree_path: Path):
    """
    RAPTORツリーを可視化
    
    Args:
        tree_path: ツリーファイルのパス
    """
    print("\n" + "=" * 70)
    print("🎨 RAPTOR ツリー可視化")
    print("=" * 70)
    
    # 可視化スクリプトを実行
    import subprocess
    
    visualize_script = Path(__file__).parent / "visualize_kasensabo_tree.py"
    
    if not visualize_script.exists():
        print(f"❌ エラー: 可視化スクリプトが見つかりません: {visualize_script}")
        return
    
    print(f"\n📊 可視化スクリプト実行中...")
    try:
        result = subprocess.run(
            [sys.executable, str(visualize_script)],
            capture_output=True,
            text=True,
            encoding='utf-8',
        )
        
        print(result.stdout)
        if result.stderr:
            print("エラー出力:", result.stderr)
        
        if result.returncode == 0:
            print("\n✅ 可視化完了")
        else:
            print(f"\n❌ 可視化エラー (code: {result.returncode})")
    except Exception as e:
        print(f"❌ エラー: {e}")
    
    print("=" * 70)


def main():
    """メイン処理"""
    parser = argparse.ArgumentParser(
        description="河川砂防技術基準 RAPTOR システム",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用例:
  # ツリーを構築
  python run_kasensabo_raptor.py --build
  
  # 検索を実行
  python run_kasensabo_raptor.py --query "堤防の維持管理"
  
  # 可視化
  python run_kasensabo_raptor.py --visualize
  
  # 全て実行（構築→可視化）
  python run_kasensabo_raptor.py --all
        """
    )
    
    parser.add_argument(
        '--build',
        action='store_true',
        help='RAPTORツリーを構築'
    )
    parser.add_argument(
        '--query',
        type=str,
        metavar='TEXT',
        help='検索クエリを実行'
    )
    parser.add_argument(
        '--visualize',
        action='store_true',
        help='ツリーを可視化'
    )
    parser.add_argument(
        '--all',
        action='store_true',
        help='構築と可視化を実行'
    )
    parser.add_argument(
        '--data-dir',
        type=str,
        default='data/kasensabo_knowledge_base',
        help='知識ベースのディレクトリ (デフォルト: data/kasensabo_knowledge_base)'
    )
    parser.add_argument(
        '--tree-file',
        type=str,
        default='kasensabo_raptor_tree.pkl',
        help='ツリーファイルのパス (デフォルト: kasensabo_raptor_tree.pkl)'
    )
    parser.add_argument(
        '--max-depth',
        type=int,
        default=3,
        help='ツリーの最大深さ (デフォルト: 3)'
    )
    parser.add_argument(
        '--max-clusters',
        type=int,
        default=8,
        help='各層の最大クラスタ数 (デフォルト: 8)'
    )
    parser.add_argument(
        '--top-k',
        type=int,
        default=5,
        help='検索結果の数 (デフォルト: 5)'
    )
    
    args = parser.parse_args()
    
    # パスを設定
    script_dir = Path(__file__).parent
    data_dir = script_dir / args.data_dir
    tree_path = script_dir / args.tree_file
    
    # 引数チェック
    if not any([args.build, args.query, args.visualize, args.all]):
        parser.print_help()
        print("\n⚠️ オプションを指定してください (--build, --query, --visualize, または --all)")
        sys.exit(1)
    
    # 実行
    try:
        if args.all or args.build:
            # ツリー構築
            build_tree(
                data_dir=data_dir,
                output_path=tree_path,
                max_depth=args.max_depth,
                max_clusters=args.max_clusters,
            )
        
        if args.query:
            # クエリ実行
            if not tree_path.exists():
                print(f"❌ エラー: ツリーファイルが見つかりません: {tree_path}")
                print("   最初に --build でツリーを構築してください")
                sys.exit(1)
            
            query_tree(
                tree_path=tree_path,
                query_text=args.query,
                top_k=args.top_k,
            )
        
        if args.all or args.visualize:
            # 可視化
            if not tree_path.exists():
                print(f"❌ エラー: ツリーファイルが見つかりません: {tree_path}")
                print("   最初に --build でツリーを構築してください")
                sys.exit(1)
            
            visualize_tree(tree_path)
        
        print("\n✅ 全ての処理が完了しました\n")
    
    except KeyboardInterrupt:
        print("\n\n⚠️ ユーザーによって中断されました")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ エラーが発生しました: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
