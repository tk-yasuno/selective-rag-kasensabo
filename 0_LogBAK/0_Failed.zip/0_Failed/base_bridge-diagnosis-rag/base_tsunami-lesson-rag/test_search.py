"""
検索機能の動作確認テスト
"""

from langchain_ollama import OllamaEmbeddings, ChatOllama
from tsunami_lesson_raptor import TsunamiLessonRAPTOR

print("="*80)
print("🧪 RAPTOR検索システム - 動作確認テスト")
print("="*80)

# モデル初期化
print("\n📦 モデル初期化中...")
embeddings = OllamaEmbeddings(model="mxbai-embed-large")
llm = ChatOllama(model="granite-code:8b", temperature=0)

# 保存済みモデルを読み込み
print("\n📂 保存済みモデルを読み込み中...")
raptor = TsunamiLessonRAPTOR.load(
    "saved_models/tsunami_lesson",
    embeddings_model=embeddings,
    llm=llm
)

# テストクエリ
test_queries = [
    "津波避難で有効だった行動は？",
    "釜石の奇跡について教えてください",
    "カウンターパート方式とは何ですか？"
]

print("\n" + "="*80)
print("🔍 テストクエリを実行")
print("="*80)

for i, query in enumerate(test_queries, 1):
    print(f"\n{'='*80}")
    print(f"テスト {i}/{len(test_queries)}: {query}")
    print('='*80)
    
    try:
        # 検索実行
        results = raptor.search_lessons(query, top_k=3)
        
        # 結果表示
        print(f"\n📄 検索結果: {len(results)}件")
        for j, (content, score, level) in enumerate(results, 1):
            print(f"\n[{j}] レベル{level} | スコア: {score:.4f}")
            print(f"{content[:200]}...")
        
        # 要約生成
        print(f"\n💡 要約生成中...")
        summary = raptor.generate_lesson_summary(query, results)
        
        print(f"\n📝 生成された要約:")
        print("-"*80)
        print(summary)
        print("-"*80)
        
    except Exception as e:
        print(f"\n❌ エラー: {str(e)}")
        import traceback
        traceback.print_exc()

print("\n" + "="*80)
print("✅ テスト完了")
print("="*80)
