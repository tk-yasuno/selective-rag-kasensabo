"""
簡易テストスクリプト - Ollamaサーバーとモデルの確認
"""

print("🔍 Checking Ollama server and models...")

try:
    from langchain_ollama import OllamaEmbeddings, ChatOllama
    print("✅ LangChain Ollama modules imported successfully")
    
    print("\n📦 Testing embedding model...")
    embeddings = OllamaEmbeddings(model="mxbai-embed-large")
    test_embedding = embeddings.embed_query("テスト")
    print(f"✅ Embedding model works! Vector dimension: {len(test_embedding)}")
    
    print("\n🤖 Testing LLM model...")
    llm = ChatOllama(model="qwen2.5:7b", temperature=0)
    response = llm.invoke("こんにちは")
    print(f"✅ LLM model works! Response: {response.content[:50]}...")
    
    print("\n✅ All models are working correctly!")
    print("   You can now run the full RAPTOR system.")
    
except Exception as e:
    print(f"\n❌ Error: {str(e)}")
    print("\n💡 Troubleshooting:")
    print("   1. Make sure Ollama is installed and running")
    print("   2. Check if models are pulled:")
    print("      > ollama list")
    print("   3. Pull required models if needed:")
    print("      > ollama pull mxbai-embed-large")
    print("      > ollama pull qwen2.5:7b")
