"""
ツリー構造のデバッグスクリプト
"""
from langchain_ollama import OllamaEmbeddings, ChatOllama
from tsunami_lesson_raptor import TsunamiLessonRAPTOR
import json

print("="*80)
print("🔍 RAPTOR ツリー構造デバッグ")
print("="*80)

# モデル初期化
print("\n📦 モデル初期化中...")
embeddings = OllamaEmbeddings(model="mxbai-embed-large")
llm = ChatOllama(model="granite-code:8b", temperature=0)

# RAPTOR初期化
raptor = TsunamiLessonRAPTOR(
    embeddings_model=embeddings,
    llm=llm,
    min_clusters=2,
    max_clusters=5,
    max_depth=2,
    chunk_size=512,
    chunk_overlap=100,
    selection_strategy='combined',
    metric_weights={'silhouette': 0.5, 'dbi': 0.5, 'chi': 0.0}
)

# データ読み込み
print("\n📚 データ読み込み中...")
documents = raptor.load_tohoku_earthquake_data()
print(f"✅ {len(documents)}個のチャンクを読み込みました")

# ツリー構築
print("\n🌲 ツリー構築中...")
tree = raptor.build_disaster_tree(documents, save_dir="../saved_models/tsunami_lesson_debug")

# ツリー構造を確認
print("\n" + "="*80)
print("🔍 ツリー構造の検査")
print("="*80)

def inspect_tree(node, indent=0):
    prefix = "  " * indent
    depth = node.get('depth', 'N/A')
    summaries_count = len(node.get('summaries', []))
    documents_count = len(node.get('documents', []))
    clusters_count = len(node.get('clusters', {}))
    
    print(f"{prefix}📦 Depth: {depth}")
    print(f"{prefix}   - Summaries: {summaries_count}")
    print(f"{prefix}   - Documents: {documents_count}")
    print(f"{prefix}   - Clusters: {clusters_count}")
    
    if documents_count > 0:
        doc = node['documents'][0]
        if hasattr(doc, 'page_content'):
            content_preview = doc.page_content[:100]
        else:
            content_preview = str(doc)[:100]
        print(f"{prefix}   - Sample doc: {content_preview}...")
    
    clusters = node.get('clusters', {})
    for cluster_id, cluster_data in clusters.items():
        print(f"{prefix}   🔗 Cluster {cluster_id}:")
        if 'children' in cluster_data:
            inspect_tree(cluster_data['children'], indent + 2)

print("\nツリー構造:")
inspect_tree(tree)

# 属性を確認
print("\n" + "="*80)
print("🔍 Raptor属性の検査")
print("="*80)
print(f"self.tree存在: {hasattr(raptor, 'tree') and raptor.tree is not None}")
print(f"self.tree_structure存在: {hasattr(raptor, 'tree_structure') and raptor.tree_structure is not None}")

if hasattr(raptor, 'tree_structure') and raptor.tree_structure:
    print(f"\nself.tree_structure keys: {raptor.tree_structure.keys()}")
    print(f"self.tree_structure depth: {raptor.tree_structure.get('depth')}")
    print(f"self.tree_structure documents: {len(raptor.tree_structure.get('documents', []))}")
    print(f"self.tree_structure clusters: {len(raptor.tree_structure.get('clusters', {}))}")

print("\n✅ デバッグ完了")
