"""
Ollama接続テスト
"""
from langchain_ollama import OllamaEmbeddings, ChatOllama

print("="*80)
print("🧪 Ollama接続テスト")
print("="*80)

# 1. Embeddings テスト
print("\n📦 Embeddings モデルをテスト中...")
try:
    embeddings = OllamaEmbeddings(
        model="mxbai-embed-large",
        base_url="http://localhost:11434"
    )
    test_text = "これはテストです"
    result = embeddings.embed_query(test_text)
    print(f"✅ Embeddings成功: ベクトル次元={len(result)}")
except Exception as e:
    print(f"❌ Embeddingsエラー: {e}")

# 2. LLM テスト
print("\n🤖 LLM モデルをテスト中...")
try:
    llm = ChatOllama(
        model="granite-code:8b",
        temperature=0,
        base_url="http://localhost:11434"
    )
    response = llm.invoke("こんにちは")
    print(f"✅ LLM成功: {response.content[:100]}...")
except Exception as e:
    print(f"❌ LLMエラー: {e}")

print("\n" + "="*80)
print("✅ テスト完了")
print("="*80)
