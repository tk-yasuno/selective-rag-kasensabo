"""
ファイル読み込みテスト
"""
from pathlib import Path

file_path = Path("tohoku_earthquake_data.txt")

# ファイルを直接読み込み
with open(file_path, 'r', encoding='utf-8') as f:
    full_text = f.read()

print(f"✅ ファイル読み込み成功")
print(f"   文字数: {len(full_text):,} characters")
print(f"   最初の100文字: {full_text[:100]}")
print(f"   最後の100文字: {full_text[-100:]}")
