"""
RAPTORツリー構築状況チェック
"""
from pathlib import Path
import json

save_dir = Path("saved_models/tsunami_lesson")

print("="*80)
print("RAPTOR Tree Build Status Check")
print("="*80)

if not save_dir.exists():
    print("\n❌ saved_models/tsunami_lesson ディレクトリが存在しません")
    print("   ツリー構築がまだ開始されていないか、エラーが発生しました。")
else:
    print(f"\n✅ ディレクトリ存在: {save_dir}")
    
    files = list(save_dir.glob("*"))
    print(f"\n📁 ファイル一覧 ({len(files)}個):")
    for f in files:
        if f.is_file():
            size = f.stat().st_size
            print(f"   - {f.name}: {size:,} bytes")
    
    # tree_structure.jsonの内容確認
    tree_file = save_dir / "tree_structure.json"
    if tree_file.exists():
        print(f"\n🌲 Tree Structure Analysis:")
        with open(tree_file, 'r', encoding='utf-8') as f:
            tree = json.load(f)
        
        print(f"   - Depth: {tree.get('depth', 'N/A')}")
        print(f"   - Summaries count: {len(tree.get('summaries', []))}")
        print(f"   - Documents count: {len(tree.get('documents', []))}")
        print(f"   - Clusters: {list(tree.get('clusters', {}).keys())}")
        
        if tree.get('summaries'):
            print(f"\n📝 First summary (preview):")
            print(f"   {tree['summaries'][0][:200]}...")
    else:
        print(f"\n⚠️  tree_structure.json がまだ作成されていません")
        print("   ツリー構築が進行中の可能性があります。")

print("\n" + "="*80)
