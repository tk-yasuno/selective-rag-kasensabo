"""
東日本大震災 教訓継承 RAPTOR システム - クイックスタート

このスクリプトは、災害教訓RAPTORシステムの基本的な使い方を示します。
"""

from langchain_ollama import OllamaEmbeddings, ChatOllama
from tsunami_lesson_raptor import TsunamiLessonRAPTOR
from pathlib import Path


def quick_demo():
    """
    クイックデモ：システムの基本的な使い方
    """
    print("="*80)
    print("🌊 東日本大震災 教訓継承 RAPTOR システム - クイックデモ")
    print("="*80)
    
    # 1. モデル初期化
    print("\n📦 モデルを初期化中...")
    embeddings = OllamaEmbeddings(model="mxbai-embed-large")
    llm = ChatOllama(model="granite-code:8b", temperature=0)
    
    # 2. RAPTORシステム初期化
    print("🌲 RAPTORシステムを初期化中...")
    raptor = TsunamiLessonRAPTOR(
        embeddings_model=embeddings,
        llm=llm,
        min_clusters=2,
        max_clusters=5,
        max_depth=3,
        chunk_size=500,
        chunk_overlap=100,
        selection_strategy='silhouette',
        metric_weights={
            'silhouette': 1.0,
            'dbi': 0.0,
            'chi': 0.0
        }
    )
    
    # 3. データ読み込み（既存のツリーがあればスキップ）
    save_dir = Path("saved_models/tsunami_lesson")
    
    if save_dir.exists() and (save_dir / "tree_structure.json").exists():
        print("\n✅ 既存のツリー構造を読み込み中...")
        raptor = TsunamiLessonRAPTOR.load(
            str(save_dir),
            embeddings_model=embeddings,
            llm=llm
        )
        # tree変数は不要（raptor.treeが使用される）
    else:
        print("\n📚 災害教訓データを読み込み中...")
        documents = raptor.load_tohoku_earthquake_data()
        
        print("\n🌲 階層ツリーを構築中（初回のみ、数分かかります）...")
        tree = raptor.build_disaster_tree(documents, save_dir=str(save_dir))
    
    # 4. インタラクティブ検索
    print("\n" + "="*80)
    print("🔍 教訓検索システム起動")
    print("="*80)
    print("\nサンプルクエリ:")
    print("  1. 津波避難で有効だった行動は？")
    print("  2. 釜石の奇跡について教えてください")
    print("  3. 災害時の情報伝達で重要なことは？")
    print("  4. カウンターパート方式とは何ですか？")
    print("  5. 復興まちづくりの課題は何ですか？")
    print("\n終了するには 'quit' または 'exit' を入力してください。")
    print("="*80)
    
    while True:
        try:
            query = input("\n質問を入力 > ").strip()
            
            if query.lower() in ['quit', 'exit', 'q']:
                print("\n👋 システムを終了します。")
                break
            
            if not query:
                continue
            
            print(f"\n🔍 検索中: '{query}'")
            
            # 検索実行（ツリーは内部で使用される）
            results = raptor.search_lessons(query, top_k=3, use_hierarchical=True)
            
            # 結果表示
            print(f"\n📄 検索結果（上位{len(results)}件）:")
            print("-"*80)
            for i, (content, score, level) in enumerate(results, 1):
                print(f"\n[{i}] スコア: {score:.4f} | 階層レベル: {level}")
                print(f"{content[:300]}...")
            
            # 要約生成
            print("\n💡 要約を生成中...")
            summary = raptor.generate_lesson_summary(query, results, context_window=2)
            
            print("\n" + "="*80)
            print("📝 生成された要約:")
            print("="*80)
            print(summary)
            print("="*80)
            
        except KeyboardInterrupt:
            print("\n\n👋 システムを終了します。")
            break
        except Exception as e:
            print(f"\n❌ エラーが発生しました: {str(e)}")
            continue


def batch_search_demo():
    """
    バッチ検索デモ：複数のクエリを一括処理
    """
    print("="*80)
    print("🌊 バッチ検索デモ")
    print("="*80)
    
    # モデル初期化
    embeddings = OllamaEmbeddings(model="mxbai-embed-large")
    llm = ChatOllama(model="granite-code:8b", temperature=0)
    
    # ツリー読み込み
    raptor = TsunamiLessonRAPTOR.load(
        "saved_models/tsunami_lesson",
        embeddings_model=embeddings,
        llm=llm
    )
    # tree変数は不要（raptor.treeが使用される）
    
    # テストクエリ
    queries = [
        "津波避難で有効だった行動は？",
        "釜石の奇跡の成功要因は？",
        "災害時の情報伝達手段として何が有効でしたか？",
        "復興における住民参加の重要性は？",
        "防災教育で重要なポイントは？"
    ]
    
    print(f"\n📋 {len(queries)}個のクエリを処理します...\n")
    
    for i, query in enumerate(queries, 1):
        print(f"\n{'='*80}")
        print(f"クエリ {i}/{len(queries)}: {query}")
        print('='*80)
        
        results = raptor.search_lessons(query, top_k=3)
        summary = raptor.generate_lesson_summary(query, results)
        
        print(f"\n💡 要約:")
        print(summary)
        print()


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "batch":
        batch_search_demo()
    else:
        quick_demo()
