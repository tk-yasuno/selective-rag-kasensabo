# 実験結果からの教訓 Part 2: Combined戦略の実証分析

**作成日**: 2025年10月18日  
**実験**: Example 2 - rag_survey.txt (631チャンク) でのCombined戦略検証  
**設定**: `metric_weights={'silhouette': 0.3, 'dbi': 0.4, 'chi': 0.3}`

---

## 📊 実験結果の詳細分析

### データセット特性
- **ファイル**: rag_survey.txt
- **サイズ**: 370,694文字
- **チャンク数**: 631
- **chunk_size**: 800
- **評価戦略**: Combined (Silhouette 30% + DBI 40% + CHI 30%)

---

## 🔍 Depth別のクラスタ選択結果

### Depth 0: ルートレベル（631 documents）

```
k=2: Sil=0.0783, DBI=3.1331, CHI=58.86, BIC=12446.44, AIC=3338.35
k=3: Sil=0.0858, DBI=3.7310, CHI=43.38, BIC=19023.75, AIC=5361.63
k=4: Sil=0.0912, DBI=3.3568, CHI=36.71, BIC=25607.10, AIC=7390.94
k=5: Sil=0.0888, DBI=3.2381, CHI=30.28, BIC=32199.90, AIC=9429.70

選択: k=2 (Combined score: 0.3000)
```

**観察:**
- ✅ **Silhouetteは増加傾向**: k=4で最大（0.0912）
- ❌ **DBIも増加傾向**: k=3で最悪（3.7310）→ クラスタ間が似ている
- ❌ **CHIは減少傾向**: k=2で最大（58.86）→ 大きなクラスタを好む
- ⚠️ **結果**: 3つの指標が矛盾し、k=2を選択

**教訓1: 指標間のトレードオフ**
```
Silhouette ↑ (k=4を好む) vs CHI ↓ (k=2を好む)
→ DBIが40%の重みでタイブレーク
→ k=2を選択（CHIの影響が強い）
```

---

### Depth 1, Branch 0: 最初のクラスタ（264 documents）

```
k=2: Sil=0.0915, DBI=4.1926, CHI=11.94, BIC=11028.55, AIC=3705.00
k=3: Sil=0.0422, DBI=4.4868, CHI=10.14, BIC=16731.34, AIC=5746.02
k=4: Sil=0.0455, DBI=3.7424, CHI=11.55, BIC=22428.84, AIC=7781.76
k=5: Sil=0.0452, DBI=3.4140, CHI=9.52, BIC=28136.47, AIC=9827.61

選択: k=2 (Combined score: 0.2903)
```

**観察:**
- ✅ **Silhouette**: k=2で最大（0.0915）→ 明確に2つのクラスタが最適
- ✅ **DBI**: k=5で最小（3.4140）→ 細かいクラスタを好む傾向
- ✅ **CHI**: k=2で最大（11.94）
- ✅ **結果**: 3つの指標が一致してk=2を選択

**教訓2: データの構造が明確な場合**
```
264 documentsという中規模データで、Silhouette/CHI が一致
→ 明確な2トピック構造が存在
→ Combined戦略が正しく機能
```

---

### Depth 1, Branch 1: 2番目のクラスタ（367 documents）

```
k=2: Sil=0.0548, DBI=4.0739, CHI=21.72, BIC=11685.14, AIC=3686.96
k=3: Sil=0.0642, DBI=3.3763, CHI=21.28, BIC=17713.87, AIC=5716.60
k=4: Sil=0.0595, DBI=3.3123, CHI=18.33, BIC=23750.78, AIC=7754.42
k=5: Sil=0.0698, DBI=2.9977, CHI=17.13, BIC=29787.04, AIC=9791.59

選択: k=3 (Combined score: 0.2814)
```

**観察:**
- ✅ **Silhouette**: k=5で最大（0.0698）→ 細かいクラスタを好む
- ✅ **DBI**: k=5で最小（2.9977）→ 同様に細かいクラスタ
- ❌ **CHI**: k=2で最大（21.72）→ 大きなクラスタを好む
- ⚠️ **結果**: k=3を選択（バランス点）

**教訓3: Combined戦略の真価**
```
Silhouette/DBI: k=5を推奨
CHI: k=2を推奨
→ Combined戦略が中間のk=3を選択
→ バランスの取れた最適化！
```

これは**Combined戦略が期待通りに機能した唯一のケース**です！

---

### Depth 2, Branch 0 (198 documents)

```
k=2: Sil=0.0584, DBI=3.7022, CHI=13.85, BIC=10503.97, AIC=3769.60
k=3: Sil=0.0362, DBI=4.7841, CHI=9.08, BIC=15916.06, AIC=5814.50
k=4: Sil=0.0497, DBI=4.1654, CHI=8.71, BIC=21324.87, AIC=7856.13
k=5: Sil=0.0251, DBI=4.2755, CHI=7.11, BIC=26738.89, AIC=9902.96

選択: k=2 (Combined score: 0.0000)
```

**観察:**
- ✅ **Silhouette**: k=2で最大（0.0584）
- ✅ **DBI**: k=2で最小（3.7022）
- ✅ **CHI**: k=2で最大（13.85）
- ✅ **結果**: 全指標が一致

**教訓4: データサイズの影響**
```
198 documentsでは、全指標がk=2で一致
→ データが小さいと、細かいクラスタリングのメリットが減少
```

---

### Depth 2, Branch 1 (66 documents) - ⚠️ 警告発生

```
WARNING: clustering 66 points to 2 centroids: please provide at least 78 training points
WARNING: clustering 66 points to 3 centroids: please provide at least 117 training points
WARNING: clustering 66 points to 4 centroids: please provide at least 156 training points
WARNING: clustering 66 points to 5 centroids: please provide at least 195 training points

k=2: Sil=0.1227, DBI=2.5086, CHI=6.46
k=3: Sil=0.0238, DBI=3.4324, CHI=4.65
k=4: Sil=0.0172, DBI=2.7807, CHI=3.54
k=5: Sil=-0.0069, DBI=2.8104, CHI=2.84

選択: k=2 (Combined score: 0.0000)
```

**観察:**
- ⚠️ **FAISSの警告**: 66点に対して2クラスタでも78点必要と警告
- ✅ **Silhouette**: k=2で突出（0.1227）→ 明確な2クラスタ構造
- ❌ **k=5でSilhouette負値**: クラスタリングが崩壊

**教訓5: 最小データサイズの重要性**
```
FAISSのk-meansは n > 39*k を推奨
66 documents → k=2でもギリギリ
→ min_clusters制限が必要
```

---

### Depth 2, Branch 2 (123 documents)

```
k=2: Sil=0.1012, DBI=2.4882, CHI=9.24
k=3: Sil=0.0688, DBI=2.9573, CHI=6.45
k=4: Sil=0.0591, DBI=3.1873, CHI=6.24 (WARNING)
k=5: Sil=0.0629, DBI=2.9560, CHI=6.44 (WARNING)

選択: k=2 (Combined score: 0.0000)
```

**観察:**
- ✅ **Silhouette**: k=2で最大（0.1012）
- ✅ **DBI**: k=2で最小（2.4882）
- ✅ **CHI**: k=2で最大（9.24）

**教訓6: 中規模データでの一貫性**
```
123 documentsでも全指標がk=2で一致
→ データサイズ < 200では、k=2が安定
```

---

## 🎯 重要な発見

### 発見1: CHIの支配的な影響

**問題:**
CHIは大きなクラスタを強く好む傾向があり、30%の重みでも影響が大きい

**証拠:**
- Depth 0: CHI=58.86 (k=2) vs 30.28 (k=5) → **1.9倍の差**
- Depth 1, Branch 1: CHI=21.72 (k=2) vs 17.13 (k=5) → 1.3倍の差

**正規化後:**
```python
# CHIの正規化
chi_scores = [58.86, 43.38, 36.71, 30.28]
chi_norm = (chi_scores - min) / (max - min)
chi_norm = [1.0, 0.46, 0.23, 0.0]  # k=2が完全に1.0

# Combined score
combined = 0.3 * sil_norm + 0.4 * dbi_norm + 0.3 * chi_norm
         = 0.3 * 0.xx + 0.4 * 0.xx + 0.3 * 1.0
         = ... + 0.3  # CHIが常に+0.3を加える
```

**教訓:**
**CHIの影響が過大評価されている可能性**

---

### 発見2: Combined戦略が機能するケース

**唯一の成功例: Depth 1, Branch 1 (367 documents)**

| 指標 | k=2 | k=3 | k=5 | 推奨 |
|------|-----|-----|-----|------|
| Silhouette | 0.0548 | 0.0642 | **0.0698** | k=5 |
| DBI | 4.0739 | 3.3763 | **2.9977** | k=5 |
| CHI | **21.72** | 21.28 | 17.13 | k=2 |
| **Combined** | - | **選択** | - | **k=3** |

**成功の条件:**
1. データサイズが十分（367 documents）
2. 指標間で意見が分かれる（Sil/DBIはk=5、CHIはk=2）
3. k=3が妥協点として機能

**教訓:**
**Combined戦略は、指標間の意見が分かれる場合にバランスを取る**

---

### 発見3: データサイズの閾値

| データサイズ | 選択されたk | 指標の一致度 | 備考 |
|-------------|-----------|-------------|------|
| 631 | k=2 | 不一致（CHI優勢） | ルートレベル |
| 367 | **k=3** | **不一致** | **Combinedが機能** |
| 264 | k=2 | 一致 | 明確な2トピック |
| 198 | k=2 | 一致 | - |
| 123 | k=2 | 一致 | - |
| 66 | k=2 | 一致（警告あり） | 最小サイズ |

**教訓:**
```
データサイズ > 300: Combined戦略が有効
データサイズ 100-300: 指標が一致しやすい（k=2）
データサイズ < 100: FAISSの警告、k=2推奨
```

---

### 発見4: 要約生成のボトルネック

**問題:**
18 documentsの要約生成で5分以上停止

**原因の可能性:**
1. LLMの応答遅延（granite-code:8bの処理速度）
2. 4000文字の要約テキストが長すぎる
3. タイムアウト設定がない

**改善策（実装済み）:**
```python
# プログレス表示追加
print(f"   🔄 Summarizing {len(documents)} documents...", end=" ", flush=True)

# エラーハンドリング
try:
    summary = chain.invoke({"text": combined_text[:4000]})
    print(f"✅ Done ({len(summary)} chars)")
except Exception as e:
    print(f"❌ Failed: {str(e)}")
    return combined_text[:500] + "..."
```

**教訓:**
**LLM呼び出しには必ずタイムアウトとフォールバックを設定**

---

## 📊 評価指標の特性分析

### Silhouette Score の特性

**長所:**
- クラスタの品質を直接評価
- 各データポイントの適切性を測定

**短所:**
- 大きなデータサイズでは計算コストが高い（O(n²)）
- rag_survey.txtでは0.05-0.12程度と低い値

**観察:**
```
Depth 0 (631 docs): 0.0783 (k=2) → 0.0912 (k=4)
Depth 1 (264 docs): 0.0915 (k=2) - 明確な2トピック
Depth 2 (66 docs):  0.1227 (k=2) - 最も高い値
```

**教訓:**
**データサイズが小さいほど、Silhouetteスコアが高い傾向**

---

### Davies-Bouldin Index の特性

**長所:**
- クラスタ間の類似度を評価
- 計算が比較的軽量（O(n*k)）

**短所:**
- 値の範囲が広い（2.5 - 4.8）
- 解釈が難しい

**観察:**
```
Depth 0: 3.13 (k=2) → 3.73 (k=3) → 3.36 (k=4) → 3.24 (k=5)
→ k=2とk=5が良好

Depth 1, Branch 1: 4.07 (k=2) → 3.38 (k=3) → 3.31 (k=4) → 3.00 (k=5)
→ k値が大きいほど改善（一貫性）
```

**教訓:**
**DBIは細かいクラスタリングを好む傾向（k=5を推奨しやすい）**

---

### Calinski-Harabasz Index の特性

**長所:**
- 計算が非常に軽量（O(n*k)）
- 分散比率で直感的

**短所:**
- **大きなクラスタを強く好む**
- k=2で常に最大値を取りやすい

**観察:**
```
Depth 0: 58.86 (k=2) → 43.38 (k=3) → 36.71 (k=4) → 30.28 (k=5)
→ k値が増えると急激に減少

正規化の影響:
CHI_norm[k=2] = 1.0
CHI_norm[k=5] = 0.0
→ Combined scoreにk=2方向の強いバイアス
```

**教訓:**
**CHIは30%の重みでも影響が大きすぎる可能性**

---

## 💡 重みづけの最適化提案

### 現在の設定（DBI重視）
```python
metric_weights = {
    'silhouette': 0.3,
    'dbi': 0.4,
    'chi': 0.3
}
```

**問題点:**
- CHIの30%がk=2方向に強く引っ張る
- DBIの40%でバランスを取ろうとするが不十分
- 結果: 7回中6回がk=2を選択

---

### 提案1: CHIの重みを削減

```python
metric_weights = {
    'silhouette': 0.4,
    'dbi': 0.5,
    'chi': 0.1  # 30% → 10%
}
```

**根拠:**
- CHIの影響を抑制
- SilhouetteとDBIでバランスを取る
- DBIが細かいクラスタを好む傾向を活用

**期待:**
- k=3, k=4の選択が増える
- より細かい階層構造

---

### 提案2: Silhouette重視

```python
metric_weights = {
    'silhouette': 0.6,
    'dbi': 0.3,
    'chi': 0.1
}
```

**根拠:**
- Silhouetteが最も直接的なクラスタ品質指標
- CHIの影響を最小化
- 精度最優先

**期待:**
- 最高品質のクラスタリング
- ビルド時間の増加

---

### 提案3: DBIとSilhouetteのみ

```python
metric_weights = {
    'silhouette': 0.5,
    'dbi': 0.5,
    'chi': 0.0  # CHIを除外
}
```

**根拠:**
- CHIのバイアスを完全に除去
- SilhouetteとDBIは相補的
- 最もバランスの取れた評価

**期待:**
- k=3, k=4, k=5の選択が増える
- Depth 1, Branch 1のような成功例が増える

---

## 🚀 実践的な推奨事項（改訂版）

### 用途1: 精度最重視
```python
retriever = RAPTORRetrieverEval(
    selection_strategy='combined',
    metric_weights={
        'silhouette': 0.6,  # 精度優先
        'dbi': 0.3,
        'chi': 0.1          # CHI抑制
    },
    min_clusters=2,
    max_clusters=10
)
```

---

### 用途2: バランス重視（推奨）
```python
retriever = RAPTORRetrieverEval(
    selection_strategy='combined',
    metric_weights={
        'silhouette': 0.5,  # バランス
        'dbi': 0.5,
        'chi': 0.0          # CHI除外
    },
    min_clusters=2,
    max_clusters=7
)
```

---

### 用途3: 速度重視
```python
retriever = RAPTORRetrieverEval(
    selection_strategy='chi',  # 単一指標で高速
    min_clusters=2,
    max_clusters=5,
    max_depth=2
)
```

---

### 用途4: 大規模データ（> 300 documents）
```python
retriever = RAPTORRetrieverEval(
    selection_strategy='combined',
    metric_weights={
        'silhouette': 0.4,
        'dbi': 0.5,
        'chi': 0.1
    },
    min_clusters=3,  # k=2を避ける
    max_clusters=8
)
```

---

## 📈 今後の実験計画

### 実験A: 重みの最適化
3つの提案を test.txt で比較
- 提案1（CHI 10%）
- 提案2（Sil 60%）
- 提案3（CHI除外）

**期待:** k=3, k=4の選択が増える

---

### 実験B: データサイズ依存の重み
```python
def adaptive_weights(n_samples):
    if n_samples > 500:
        return {'silhouette': 0.5, 'dbi': 0.5, 'chi': 0.0}
    elif n_samples > 200:
        return {'silhouette': 0.4, 'dbi': 0.5, 'chi': 0.1}
    else:
        return {'silhouette': 0.3, 'dbi': 0.4, 'chi': 0.3}
```

---

### 実験C: 階層依存の戦略
```python
def adaptive_strategy(depth, n_samples):
    if depth == 0:
        return 'combined', {'sil': 0.5, 'dbi': 0.5, 'chi': 0.0}
    elif n_samples < 100:
        return 'silhouette', None  # 単一指標
    else:
        return 'combined', {'sil': 0.4, 'dbi': 0.5, 'chi': 0.1}
```

---

## 🎓 理論的考察

### なぜCHIはk=2を好むのか

**Calinski-Harabasz Index の定義:**
```
CHI = [SS_between / (k-1)] / [SS_within / (n-k)]
    = [クラスタ間分散 / (k-1)] / [クラスタ内分散 / (n-k)]
```

**k=2の優位性:**
1. 分母の `k-1` が最小（= 1）
2. クラスタ間分散を最大化しやすい
3. 2つの大きなクラスタ → クラスタ内分散が許容範囲

**k=5の劣位性:**
1. 分母の `k-1` が大きい（= 4）
2. 小さなクラスタ → クラスタ間分散が小さい
3. CHIスコアが低下

**結論:**
**CHIは構造的にk=2を好むバイアスがある**

---

### SilhouetteとDBIの相補性

**Silhouette:**
- データポイント単位の評価
- 各点が適切なクラスタに属しているか

**DBI:**
- クラスタ単位の評価
- クラスタ間の分離度

**相補性:**
```
Silhouette: ミクロな視点（個々のデータポイント）
DBI: マクロな視点（クラスタ全体）
→ 組み合わせで多角的に評価
```

**実証:**
Depth 1, Branch 1 (367 docs) で両者がk=5を推奨し、Combined戦略が機能

---

## 📝 まとめ

### 主要な発見

1. **CHIの支配的影響**
   - 30%の重みでもk=2方向に強いバイアス
   - 正規化後の影響が過大評価

2. **Combined戦略の成功条件**
   - データサイズ > 300
   - 指標間で意見が分かれる
   - k=3が妥協点として機能

3. **データサイズの閾値**
   - > 300: Combined有効
   - 100-300: k=2で安定
   - < 100: FAISS警告

4. **LLM要約のボトルネック**
   - タイムアウトとエラーハンドリングが必須

### 推奨される改善

1. **重みの最適化**
   - CHI: 30% → 10% or 0%
   - Silhouette + DBI 重視

2. **適応的な戦略**
   - データサイズに応じて重みを調整
   - 階層深さに応じて戦略を変更

3. **min_clustersの調整**
   - データサイズ < 100: min_clusters=2（警告回避）
   - データサイズ > 300: min_clusters=3（k=2を避ける）

### 次のステップ

1. ✅ **Example 2 実行完了** - Combined戦略の検証
2. ⏳ **重み最適化実験** - 提案1-3の検証
3. ⏳ **適応的戦略の実装**
4. ⏳ **本番環境での推奨設定決定**

---

**更新日**: 2025年10月18日  
**バージョン**: 2.0  
**ステータス**: Example 2 部分実行、改善提案済み
