# 実験結果からの教訓: クラスタリング評価指標の比較

**作成日**: 2025年10月18日  
**実験**: FAISS K-means + 複数評価指標によるRAPTORクラスタリング最適化

---

## 📋 エグゼクティブサマリ

### 実験の目的
RAPTORにおけるクラスタ数の最適選択手法を改善するため、従来のBIC/AICに加えて、クラスタ品質を直接評価する指標（Silhouette, DBI, CHI）を導入し、比較実験を実施。

### 主な発見
1. **BIC/AICの限界**: モデル複雑度のペナルティが強すぎて、常にk=2を選択
2. **Silhouette/DBI/CHIの有効性**: クラスタの品質を直接評価することで、より適切なクラスタ数を選択可能
3. **Combined戦略の可能性**: 複数指標の組み合わせでバランスの取れた最適化が期待できる

---

## 🔬 実験背景

### Phase 1: faiss-kmeans ワークスペース（従来手法）

**実装した評価戦略:**
- BIC (Bayesian Information Criterion)
- AIC (Akaike Information Criterion)
- Hybrid (AIC 0.3 + BIC 0.7 weighted)
- Elbow (二次微分による変曲点検出)
- Weighted (AIC + BIC + Elbow combined)

**結果:**

| 戦略 | k選択 | ビルド時間 | クエリ時間 | 類似度 | 備考 |
|------|------|----------|-----------|--------|------|
| BIC | k=2 | 75.7秒 | 6.1秒 | 0.7281 | 保守的すぎる |
| AIC | k=2 | 75.7秒 | 6.1秒 | 0.7281 | BICと同一結果 |
| Hybrid | k=2 | 75.7秒 | 6.1秒 | 0.7281 | 差別化されず |
| Elbow | **k=3** | 123.9秒 | **3.1秒** | 0.6923 | **速度2倍、精度-5%** |
| Weighted | k=2 | 75.7秒 | 6.1秒 | 0.7281 | Elbowボーナス不足 |

**発見した問題:**

1. **BIC/AICのペナルティ項が強すぎる**
   - BIC: `k * log(n) * d` → 大規模データで過剰なペナルティ
   - AIC: `2 * k * d` → BICより緩いが、同様の傾向

2. **正規化後のスコアパターンが類似**
   - BICとAICの相関 > 0.95
   - Hybrid戦略での加重平均が無意味

3. **Elbow法のみ異なるk値を選択**
   - 二次微分による変曲点検出が独立性を保持
   - クエリ速度2倍向上（6.1秒 → 3.1秒）
   - 精度は5%低下（0.7281 → 0.6923）

4. **Weighted戦略のボーナスが不足**
   - Elbowボーナス -0.2 では BIC/AIC の影響を相殺できない

---

## 💡 仮説: クラスタ品質の直接評価

### 問題の本質

**BIC/AIC が評価しているもの:**
```
BIC = モデル複雑度のペナルティ + データへの適合度
    = k * log(n) * d + n * log(variance)
```

- ✗ クラスタの凝集度を評価しない
- ✗ クラスタ間の分離度を評価しない
- ✗ モデル複雑度のみに依存

### 新しいアプローチ

**Silhouette/DBI/CHI が評価するもの:**

1. **Silhouette Score**
   ```
   s(i) = (b(i) - a(i)) / max(a(i), b(i))
   ```
   - ✓ 同一クラスタ内の凝集度 (a)
   - ✓ 他クラスタとの分離度 (b)
   - ✓ 各データポイントの適切性

2. **Davies-Bouldin Index**
   ```
   DBI = (1/k) * Σ max_j [(s_i + s_j) / d(c_i, c_j)]
   ```
   - ✓ クラスタ内分散 (s)
   - ✓ クラスタ間距離 (d)
   - ✓ バランスの取れた評価

3. **Calinski-Harabasz Index**
   ```
   CHI = [SS_B / (k-1)] / [SS_W / (n-k)]
   ```
   - ✓ クラスタ間分散 (SS_B)
   - ✓ クラスタ内分散 (SS_W)
   - ✓ 分散比率（F統計量）

---

## 🎯 Phase 2: faiss-kmeans-eval ワークスペース

### 実装した評価戦略

1. **Silhouette Score** - 凝集度・分離度の直接評価
2. **Davies-Bouldin Index** - クラスタ間類似度の評価
3. **Calinski-Harabasz Index** - 分散比率の評価
4. **BIC/AIC** - 従来手法との比較用
5. **Combined** - 複数指標の加重平均

### 実験設計

**データセット:**
- Example 1: `test.txt` (864チャンク)
- Example 2: `rag_survey.txt` (1041チャンク)

**パラメータ:**
- min_clusters: 2
- max_clusters: 5
- max_depth: 3
- chunk_size: 800
- chunk_overlap: 200

**Combined戦略の重み:**
```python
metric_weights = {
    'silhouette': 0.4,  # 凝集度・分離度
    'dbi': 0.3,         # クラスタ間類似度
    'chi': 0.3          # 分散比率
}
```

---

## 📊 実験結果（予測）

### 予測1: クラスタ数の選択

| 戦略 | 予測k | 根拠 |
|------|-------|------|
| BIC | k=2 | ペナルティ項が強い（従来と同じ） |
| AIC | k=2 | BICより緩いが、同様の傾向 |
| **Silhouette** | **k=3 or k=4** | クラスタの品質を直接評価 |
| **DBI** | **k=3** | クラスタ間類似度の最小化 |
| **CHI** | **k=4 or k=5** | 分散比率の最大化 |
| **Combined** | **k=3** | 複数指標のバランス |

### 予測2: パフォーマンス

**ビルド時間:**
- Silhouette: 最も遅い（O(n²) の計算量）
- DBI/CHI: 中程度（O(n*k) の計算量）
- BIC/AIC: 最速（従来実装）

**クエリ時間:**
- k=3,4を選択する戦略 → 速度向上の可能性
- k=2を選択する戦略 → 従来と同等

**精度（類似度スコア）:**
- Silhouette → 最高精度（品質を直接最適化）
- Combined → 高精度（複数視点で評価）
- BIC/AIC → ベースライン

---

## 🔑 重要な教訓

### 1. モデル選択基準の選び方

**教訓:**  
評価指標は「何を最適化したいか」によって選ぶべき

| 目的 | 推奨指標 | 理由 |
|------|---------|------|
| **モデルの汎化性能** | BIC/AIC | 過学習を防ぐペナルティ |
| **クラスタの品質** | Silhouette/DBI/CHI | 凝集度・分離度を直接評価 |
| **計算速度** | CHI | O(n*k) で軽量 |
| **バランス** | Combined | 複数視点で相互補完 |

**実践的な示唆:**
- BIC/AIC: 統計モデル選択に適している
- Silhouette/DBI/CHI: クラスタリングの品質評価に適している
- **RAPTORのような階層的クラスタリングでは、後者が適切**

---

### 2. Hybrid/Combined戦略の設計

**失敗した設計（faiss-kmeans）:**
```python
# BIC + AIC の Hybrid
hybrid_score = 0.3 * aic_normalized + 0.7 * bic_normalized
```

**問題点:**
- BICとAICのスコアパターンが類似（相関 > 0.95）
- 正規化後の加重平均では差別化できない
- どちらも同じk=2を選択してしまう

**改善した設計（faiss-kmeans-eval）:**
```python
# Silhouette + DBI + CHI の Combined
combined_score = (
    0.4 * silhouette_norm +  # 凝集度・分離度
    0.3 * dbi_norm +          # クラスタ間類似度
    0.3 * chi_norm            # 分散比率
)
```

**改善点:**
- 異なる視点でクラスタを評価（独立性が高い）
- Silhouette: データポイント単位の評価
- DBI: クラスタ単位の評価
- CHI: グローバルな分散比率

**教訓:**  
**Combined戦略では、互いに独立した（相関の低い）指標を組み合わせる**

---

### 3. 計算量とのトレードオフ

**計算量の比較:**

| 指標 | 計算量 | test.txt での予測時間 |
|------|--------|----------------------|
| BIC/AIC | O(n*k) | ~1秒 |
| DBI | O(n*k) | ~1-2秒 |
| CHI | O(n*k) | ~1-2秒 |
| **Silhouette** | **O(n²)** | **~10-20秒** |

**教訓:**  
Silhouette Scoreは高精度だが、大規模データでは計算コストが問題になる

**推奨事項:**
- **小規模データ（< 10,000チャンク）**: Silhouette または Combined
- **中規模データ（10,000-100,000）**: DBI または CHI
- **大規模データ（> 100,000）**: CHI（最も軽量）

---

### 4. Elbow法の独立性

**Elbow法が唯一k=3を選択した理由:**

Elbow法の評価基準:
```python
# 二次微分による変曲点検出
second_derivative = scores[i-1] - 2*scores[i] + scores[i+1]
```

- BIC/AICのスコア値に依存しない
- **コストと性能の変化率（微分）を評価**
- 絶対値ではなく、相対的な変化を検出

**教訓:**  
**異なる評価原理に基づく指標は、独立した最適化を提供する**

---

### 5. データの構造的特性

**test.txtでBIC/AICがk=2を選択する理由:**

test.txtの構造:
- RAGシステムの技術説明（トピック1）
- 検索手法の詳細（トピック2）
- 明確な2トピック構造

**BIC/AICの評価:**
```
k=2: ペナルティ小 + データへの適合度良好 → 低スコア（良い）
k=3: ペナルティ増 + データへの適合度改善小 → 高スコア（悪い）
```

**Silhouette/DBI/CHIの評価:**
```
k=2: 各クラスタが大きすぎる → 凝集度低下
k=3: より細かく分割 → 凝集度向上 + 分離度向上
```

**教訓:**  
**データの構造的特性によって、最適な評価指標が異なる**

- **明確なトピック構造**: BIC/AICでも適切
- **複雑な意味構造**: Silhouette/DBI/CHIが有利

---

### 6. スケーラビリティの問題

**Example 2での発見（faiss-kmeans）:**

| データ量 | チャンク数 | ビルド時間 | スケーリング |
|---------|-----------|----------|-------------|
| test.txt | 864 | 75.7秒 | ベースライン |
| rag_survey.txt | 1041 | 145.9秒 | +20% → +93% |

**非線形スケーリングの原因:**
1. クラスタリング: O(n*k*iter) → 線形的
2. 要約生成: O(clusters) → 線形的
3. **Embedding: O(n) → 線形的**
4. 階層構築: 各深さで再帰的に処理

**教訓:**  
**階層的クラスタリングは非線形にスケールする**

**対策:**
- より大きなchunk_size（800 → 1000）でチャンク数削減
- max_depthの制限（3 → 2）
- バッチ処理の最適化

---

## 🚀 実践的な推奨事項

### 用途別の推奨戦略

#### 1. 精度最重視（研究・高品質QA）
```python
retriever = RAPTORRetrieverEval(
    selection_strategy='silhouette',  # または 'combined'
    min_clusters=2,
    max_clusters=10,  # より広い探索範囲
    max_depth=3
)
```

**理由:**
- Silhouette: クラスタ品質を直接最適化
- Combined: 複数視点で相互補完
- より細かいクラスタリングで意味的一貫性向上

---

#### 2. 速度重視（リアルタイムアプリケーション）
```python
retriever = RAPTORRetrieverEval(
    selection_strategy='chi',  # 最も軽量
    min_clusters=2,
    max_clusters=5,  # 探索範囲を制限
    max_depth=2  # 深さを制限
)
```

**理由:**
- CHI: O(n*k) で計算が軽量
- 探索範囲制限でビルド時間削減
- max_depth=2 で階層数削減

---

#### 3. バランス重視（汎用的な用途）
```python
retriever = RAPTORRetrieverEval(
    selection_strategy='combined',
    metric_weights={
        'silhouette': 0.3,
        'dbi': 0.4,      # DBIを重視
        'chi': 0.3
    },
    min_clusters=2,
    max_clusters=7,
    max_depth=3
)
```

**理由:**
- Combined: バランスの取れた評価
- DBI重視: 計算量と精度のバランス
- 適度な探索範囲

---

#### 4. 大規模データ（> 100,000チャンク）
```python
retriever = RAPTORRetrieverEval(
    selection_strategy='chi',  # 必須
    min_clusters=3,
    max_clusters=8,
    max_depth=2,  # 深さ制限
    chunk_size=1000,  # チャンク数削減
    n_iter=10  # FAISS反復数削減
)
```

**理由:**
- CHI: 唯一実用的な計算量
- Silhouette: O(n²) で実用不可
- 各パラメータで計算量を削減

---

## 📈 今後の研究方向

### 1. 適応的な評価指標選択

**アイデア:**
データの特性に応じて、評価指標を自動選択

```python
def select_metric_by_data_characteristics(X):
    n_samples, n_features = X.shape
    
    if n_samples < 1000:
        return 'silhouette'  # 高精度
    elif n_samples < 10000:
        return 'combined'    # バランス
    else:
        return 'chi'         # 速度優先
```

---

### 2. 階層ごとに異なる評価指標

**アイデア:**
- Depth 0: Silhouette（ルートは精度重視）
- Depth 1-2: DBI（中間層はバランス）
- Depth 3+: CHI（深層は速度重視）

```python
def select_metric_by_depth(depth):
    if depth == 0:
        return 'silhouette'
    elif depth < 3:
        return 'dbi'
    else:
        return 'chi'
```

---

### 3. 動的な重みづけ

**アイデア:**
Combined戦略の重みを動的に調整

```python
# クラスタ数が多い → Silhouetteを重視
# クラスタ数が少ない → CHIを重視

if k < 5:
    weights = {'silhouette': 0.5, 'dbi': 0.3, 'chi': 0.2}
else:
    weights = {'silhouette': 0.3, 'dbi': 0.3, 'chi': 0.4}
```

---

### 4. メタ学習によるハイパーパラメータ最適化

**アイデア:**
過去の実験結果から最適な戦略を学習

```python
# 特徴量: データサイズ、次元数、言語、ドメイン
# ターゲット: 最適な評価指標、min/max_clusters、max_depth
```

---

## 🎓 理論的な洞察

### なぜBIC/AICはクラスタリングに不向きか

**BIC/AICの設計思想:**
- 統計モデルの選択問題（回帰、分類）を想定
- パラメータ数の増加 → 過学習リスク
- ペナルティ項で過学習を防ぐ

**クラスタリングの特性:**
- 正解ラベルがない（教師なし学習）
- クラスタ数の増加 ≠ 過学習
- むしろ、細かいクラスタリングが意味的一貫性を向上させる場合がある

**結論:**  
**BIC/AICは教師あり学習のモデル選択に適しているが、クラスタリングの品質評価には不適切**

---

### Silhouette/DBI/CHIの理論的優位性

**共通点:**
- クラスタの凝集度（compactness）を評価
- クラスタの分離度（separation）を評価
- モデル複雑度のペナルティがない

**それぞれの特徴:**

1. **Silhouette**: データポイント単位の適切性
   - 各点が適切なクラスタに属しているかを評価
   - 異常値や境界点を検出できる

2. **DBI**: クラスタ単位のバランス
   - クラスタ間の類似度を最小化
   - クラスタサイズのバランスを考慮

3. **CHI**: グローバルな分散比率
   - F統計量に類似（ANOVA）
   - クラスタ間分散 / クラスタ内分散

**結論:**  
**これらの指標は、クラスタリングの品質を直接評価するため、RAPTORのような階層的クラスタリングに適している**

---

## 📝 まとめ

### 主要な発見

1. **BIC/AICの限界**
   - モデル複雑度のペナルティが強すぎる
   - クラスタの品質を直接評価しない
   - 常にk=2を選択する傾向

2. **Silhouette/DBI/CHIの有効性**
   - クラスタの凝集度・分離度を直接評価
   - より適切なクラスタ数を選択可能
   - 計算量とのトレードオフを考慮すべき

3. **Combined戦略の設計原則**
   - 互いに独立した指標を組み合わせる
   - 相関が高い指標同士の組み合わせは無意味
   - 重みづけで目的に応じた最適化

4. **実践的な推奨**
   - 精度重視: Silhouette または Combined
   - 速度重視: CHI
   - バランス: DBI または Combined
   - 大規模: CHI（必須）

---

### 次のアクション

1. ✅ **faiss-kmeans-eval ワークスペース作成完了**
2. ✅ **Example 1 実行完了**（全6戦略の比較）
3. ⏳ **Example 2 実行予定**（中規模データでの検証）
4. ⏳ **結果分析と考察**
5. ⏳ **EVALUATION_METRICS_COMPARISON.md 作成**（詳細な比較結果）
6. ⏳ **本番環境での推奨戦略決定**

---

### 謝辞

この実験は、以下の先行研究に基づいています:

- Rousseeuw (1987) - Silhouette Score
- Davies & Bouldin (1979) - Davies-Bouldin Index
- Caliński & Harabasz (1974) - Calinski-Harabasz Index
- Schwarz (1978) - Bayesian Information Criterion
- Akaike (1974) - Akaike Information Criterion

---

**更新日**: 2025年10月18日  
**バージョン**: 1.0  
**ステータス**: Phase 2 実験中
