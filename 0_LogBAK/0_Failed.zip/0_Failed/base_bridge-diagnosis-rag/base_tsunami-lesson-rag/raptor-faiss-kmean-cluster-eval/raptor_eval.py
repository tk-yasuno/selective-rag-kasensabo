"""
RAPTOR with FAISS + Multiple Clustering Evaluation Metrics

複数のクラスタリング評価指標を統合した RAPTOR 実装
- Silhouette Score (クラスタの凝集度と分離度)
- Davies-Bouldin Index (クラスタ間類似度とクラスタ内分散)
- Calinski-Harabasz Index (分散比率)
- BIC (Bayesian Information Criterion)
- AIC (Akaike Information Criterion)

Version: 3.0 - Evaluation Metrics Edition
"""

from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.documents import Document
import faiss
import numpy as np
from typing import List, Dict, Tuple, Optional
import time
import json
import pickle
from pathlib import Path
from sklearn.metrics import silhouette_score, davies_bouldin_score, calinski_harabasz_score


class RAPTORRetrieverEval:
    """
    RAPTOR with Multiple Clustering Evaluation Metrics
    
    複数の評価指標でクラスタ数を最適化
    """
    
    def __init__(
        self,
        embeddings_model,
        llm,
        min_clusters: int = 2,
        max_clusters: int = 10,
        max_depth: int = 3,
        chunk_size: int = 800,
        chunk_overlap: int = 200,
        n_iter: int = 20,
        selection_strategy: str = 'silhouette',
        metric_weights: Dict[str, float] = None
    ):
        """
        Args:
            embeddings_model: Embeddings model
            llm: LLM for summarization
            min_clusters: 最小クラスタ数
            max_clusters: 最大クラスタ数
            max_depth: 最大階層深さ
            chunk_size: チャンクサイズ
            chunk_overlap: チャンク重複
            n_iter: FAISS k-meansの反復回数
            selection_strategy: クラスタ数選択戦略
                - 'silhouette': Silhouette Score (推奨)
                - 'dbi': Davies-Bouldin Index
                - 'chi': Calinski-Harabasz Index
                - 'bic': BIC (従来手法)
                - 'aic': AIC
                - 'combined': 複数指標の組み合わせ
            metric_weights: combined戦略での重み
                例: {'silhouette': 0.4, 'dbi': 0.3, 'chi': 0.3}
        """
        self.embeddings_model = embeddings_model
        self.llm = llm
        self.min_clusters = min_clusters
        self.max_clusters = max_clusters
        self.max_depth = max_depth
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.n_iter = n_iter
        self.selection_strategy = selection_strategy
        
        # デフォルトの重み設定
        # 実験結果: CHIはk=2を強く好むバイアスがあるため除外
        # Silhouette + DBI のバランスで最適化
        if metric_weights is None:
            self.metric_weights = {
                'silhouette': 0.5,  # クラスタ品質（ミクロ視点）
                'dbi': 0.5,         # クラスタ分離度（マクロ視点）
                'chi': 0.0          # CHI除外（k=2バイアス回避）
            }
        else:
            self.metric_weights = metric_weights
        
        self.tree_structure = {}
        self.stats = {
            'selections': [],
            'silhouette_scores': [],
            'dbi_scores': [],
            'chi_scores': [],
            'bic_scores': [],
            'aic_scores': []
        }
        
        print(f"RAPTOR with {selection_strategy.upper()} evaluation initialized")
        print(f"   Parameters:")
        print(f"   - Cluster range: {min_clusters}-{max_clusters}")
        print(f"   - Strategy: {selection_strategy}")
        if selection_strategy == 'combined':
            print(f"   - Weights: {metric_weights}")
        print(f"   - max_depth: {max_depth}")
        print(f"   - chunk_size: {chunk_size}")
    
    def load_and_split_documents(self, file_path: str, encoding: str = "utf-8") -> List[Document]:
        """ドキュメントを読み込み、チャンクに分割"""
        loader = TextLoader(file_path, encoding=encoding)
        documents = loader.load()
        
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=self.chunk_size,
            chunk_overlap=self.chunk_overlap,
            length_function=len,
        )
        
        chunks = text_splitter.split_documents(documents)
        
        print(f"Loaded document length: {len(documents[0].page_content)} characters")
        print(f"Split into {len(chunks)} chunks")
        
        return chunks
    
    def embed_documents(self, documents: List[Document], batch_size: int = 100) -> np.ndarray:
        """ドキュメントをバッチで埋め込み"""
        all_embeddings = []
        
        for i in range(0, len(documents), batch_size):
            batch = documents[i:i + batch_size]
            texts = [doc.page_content if isinstance(doc, Document) else doc for doc in batch]
            embeddings = self.embeddings_model.embed_documents(texts)
            all_embeddings.extend(embeddings)
        
        return np.array(all_embeddings, dtype=np.float32)
    
    def faiss_kmeans(self, X: np.ndarray, k: int) -> Tuple[np.ndarray, np.ndarray]:
        """
        FAISSによる高速k-means
        
        Args:
            X: データ行列 (n_samples, n_features)
            k: クラスタ数
            
        Returns:
            labels: クラスタラベル
            centroids: クラスタ中心
        """
        n_samples, d = X.shape
        
        if n_samples < k:
            k = n_samples
        
        kmeans = faiss.Kmeans(
            d=d,
            k=k,
            niter=self.n_iter,
            verbose=False,
            gpu=False
        )
        
        kmeans.train(X)
        _, labels = kmeans.index.search(X, 1)
        
        return labels.ravel(), kmeans.centroids
    
    def compute_silhouette(self, X: np.ndarray, labels: np.ndarray) -> float:
        """
        Silhouette Score を計算
        
        範囲: -1 〜 +1 (大きいほど良い)
        """
        n_clusters = len(np.unique(labels))
        
        if n_clusters <= 1 or n_clusters >= len(X):
            return -1.0
        
        try:
            return silhouette_score(X, labels, metric='euclidean')
        except:
            return -1.0
    
    def compute_dbi(self, X: np.ndarray, labels: np.ndarray) -> float:
        """
        Davies-Bouldin Index を計算
        
        小さいほど良い
        """
        n_clusters = len(np.unique(labels))
        
        if n_clusters <= 1:
            return float('inf')
        
        try:
            return davies_bouldin_score(X, labels)
        except:
            return float('inf')
    
    def compute_chi(self, X: np.ndarray, labels: np.ndarray) -> float:
        """
        Calinski-Harabasz Index を計算
        
        大きいほど良い
        """
        n_clusters = len(np.unique(labels))
        
        if n_clusters <= 1 or n_clusters >= len(X):
            return 0.0
        
        try:
            return calinski_harabasz_score(X, labels)
        except:
            return 0.0
    
    def compute_bic(self, X: np.ndarray, labels: np.ndarray, centroids: np.ndarray) -> float:
        """BIC計算（従来手法との比較用）"""
        n_samples, dim = X.shape
        k = len(np.unique(labels))
        
        distances = []
        for i in range(n_samples):
            cluster_id = labels[i]
            centroid = centroids[cluster_id]
            dist = np.linalg.norm(X[i] - centroid)
            distances.append(dist)
        
        distances = np.array(distances)
        variance = np.sum(distances ** 2) / (n_samples - k)
        
        penalty = k * np.log(n_samples) * dim
        likelihood = n_samples * np.log(variance + 1e-10)
        
        return penalty + likelihood
    
    def compute_aic(self, X: np.ndarray, labels: np.ndarray, centroids: np.ndarray) -> float:
        """AIC計算（従来手法との比較用）"""
        n_samples, dim = X.shape
        k = len(np.unique(labels))
        
        distances = []
        for i in range(n_samples):
            cluster_id = labels[i]
            centroid = centroids[cluster_id]
            dist = np.linalg.norm(X[i] - centroid)
            distances.append(dist)
        
        distances = np.array(distances)
        variance = np.sum(distances ** 2) / (n_samples - k)
        
        penalty = 2 * k * dim
        likelihood = n_samples * np.log(variance + 1e-10)
        
        return penalty + likelihood
    
    def normalize_scores(self, scores: List[float], reverse: bool = False) -> np.ndarray:
        """
        スコアを0-1に正規化
        
        Args:
            scores: スコアリスト
            reverse: Trueの場合、大きい値が良いスコアを反転（小さい値が良い形式に）
        """
        scores = np.array(scores)
        min_score = np.min(scores)
        max_score = np.max(scores)
        
        if max_score - min_score < 1e-10:
            return np.zeros_like(scores)
        
        normalized = (scores - min_score) / (max_score - min_score)
        
        if reverse:
            normalized = 1.0 - normalized
        
        return normalized
    
    def select_optimal_k(self, X: np.ndarray) -> Tuple[int, np.ndarray, np.ndarray, Dict]:
        """
        複数の評価指標による最適クラスタ数選択
        
        Returns:
            best_k: 最適クラスタ数
            best_labels: クラスタラベル
            best_centroids: クラスタ中心
            scores_dict: 各指標のスコア
        """
        n_samples = X.shape[0]
        
        max_k = min(self.max_clusters, n_samples)
        min_k = min(self.min_clusters, max_k)
        
        print(f"\n🔍 Evaluating cluster count using {self.selection_strategy.upper()}...")
        print(f"   Range: {min_k} to {max_k} clusters")
        
        # 各kに対してクラスタリングと評価
        silhouette_scores = []
        dbi_scores = []
        chi_scores = []
        bic_scores = []
        aic_scores = []
        labels_list = []
        centroids_list = []
        
        for k in range(min_k, max_k + 1):
            labels, centroids = self.faiss_kmeans(X, k)
            labels_list.append(labels)
            centroids_list.append(centroids)
            
            # 各評価指標を計算
            sil = self.compute_silhouette(X, labels)
            dbi = self.compute_dbi(X, labels)
            chi = self.compute_chi(X, labels)
            bic = self.compute_bic(X, labels, centroids)
            aic = self.compute_aic(X, labels, centroids)
            
            silhouette_scores.append(sil)
            dbi_scores.append(dbi)
            chi_scores.append(chi)
            bic_scores.append(bic)
            aic_scores.append(aic)
            
            print(f"   k={k}: Sil={sil:.4f}, DBI={dbi:.4f}, CHI={chi:.2f}, BIC={bic:.2f}, AIC={aic:.2f}")
        
        # 戦略に応じて最適kを選択
        if self.selection_strategy == 'silhouette':
            best_idx = np.argmax(silhouette_scores)
            print(f"\n✅ Strategy: Silhouette Score (maximize)")
            print(f"   Selected k={min_k + best_idx} (Score={silhouette_scores[best_idx]:.4f})")
            
        elif self.selection_strategy == 'dbi':
            best_idx = np.argmin(dbi_scores)
            print(f"\n✅ Strategy: Davies-Bouldin Index (minimize)")
            print(f"   Selected k={min_k + best_idx} (Score={dbi_scores[best_idx]:.4f})")
            
        elif self.selection_strategy == 'chi':
            best_idx = np.argmax(chi_scores)
            print(f"\n✅ Strategy: Calinski-Harabasz Index (maximize)")
            print(f"   Selected k={min_k + best_idx} (Score={chi_scores[best_idx]:.2f})")
            
        elif self.selection_strategy == 'bic':
            best_idx = np.argmin(bic_scores)
            print(f"\n✅ Strategy: BIC (minimize)")
            print(f"   Selected k={min_k + best_idx} (Score={bic_scores[best_idx]:.2f})")
            
        elif self.selection_strategy == 'aic':
            best_idx = np.argmin(aic_scores)
            print(f"\n✅ Strategy: AIC (minimize)")
            print(f"   Selected k={min_k + best_idx} (Score={aic_scores[best_idx]:.2f})")
            
        elif self.selection_strategy == 'combined':
            # 正規化して組み合わせ
            sil_norm = self.normalize_scores(silhouette_scores, reverse=True)  # 大→小に反転
            dbi_norm = self.normalize_scores(dbi_scores, reverse=False)  # 小さい方が良い
            chi_norm = self.normalize_scores(chi_scores, reverse=True)  # 大→小に反転
            
            # 加重スコア（小さいほど良い形式に統一）
            combined = (
                self.metric_weights.get('silhouette', 0.4) * sil_norm +
                self.metric_weights.get('dbi', 0.3) * dbi_norm +
                self.metric_weights.get('chi', 0.3) * chi_norm
            )
            
            best_idx = np.argmin(combined)
            print(f"\n✅ Strategy: Combined Metrics")
            print(f"   Weights: {self.metric_weights}")
            print(f"   Selected k={min_k + best_idx}")
            print(f"   - Silhouette: {silhouette_scores[best_idx]:.4f}")
            print(f"   - DBI: {dbi_scores[best_idx]:.4f}")
            print(f"   - CHI: {chi_scores[best_idx]:.2f}")
            print(f"   - Combined score: {combined[best_idx]:.4f}")
        
        else:
            # デフォルトはSilhouette
            best_idx = np.argmax(silhouette_scores)
            print(f"\n⚠️  Unknown strategy, using Silhouette")
        
        best_k = min_k + best_idx
        best_labels = labels_list[best_idx]
        best_centroids = centroids_list[best_idx]
        
        scores_dict = {
            'silhouette': silhouette_scores,
            'dbi': dbi_scores,
            'chi': chi_scores,
            'bic': bic_scores,
            'aic': aic_scores,
            'k_range': list(range(min_k, max_k + 1))
        }
        
        # 統計記録
        self.stats['selections'].append(best_k)
        self.stats['silhouette_scores'].append(silhouette_scores[best_idx])
        self.stats['dbi_scores'].append(dbi_scores[best_idx])
        self.stats['chi_scores'].append(chi_scores[best_idx])
        
        return best_k, best_labels, best_centroids, scores_dict
    
    def cluster_documents(self, X: np.ndarray) -> Tuple[np.ndarray, int]:
        """ドキュメントをクラスタリング"""
        best_k, labels, centroids, scores = self.select_optimal_k(X)
        return labels, best_k
    
    def summarize_cluster(self, documents: List[Document]) -> str:
        """クラスタを要約（リトライ機能付き）"""
        print(f"   🔄 Summarizing {len(documents)} documents...", end=" ", flush=True)
        
        combined_text = "\n\n".join([doc.page_content for doc in documents])
        
        prompt = ChatPromptTemplate.from_template(
            "以下のテキストを簡潔に要約してください。重要なポイントを保持しながら、"
            "全体の内容を200-300文字程度でまとめてください:\n\n{text}"
        )
        
        chain = prompt | self.llm | StrOutputParser()
        
        # リトライ機能（最大3回試行）
        max_retries = 3
        for attempt in range(max_retries):
            try:
                summary = chain.invoke({"text": combined_text[:4000]})
                print(f"✅ Done ({len(summary)} chars)")
                return summary
            except Exception as e:
                if attempt < max_retries - 1:
                    print(f"⚠️ Retry {attempt + 1}/{max_retries}...", end=" ", flush=True)
                    import time
                    time.sleep(2)  # 2秒待機してリトライ
                else:
                    print(f"❌ Failed after {max_retries} attempts: {str(e)}")
                    # フォールバック: 最初の500文字を返す
                    return combined_text[:500] + "..."
    
    def build_tree(self, documents: List[Document], depth: int = 0) -> Dict:
        """再帰的に階層ツリーを構築"""
        print(f"\n{'='*80}")
        print(f"Building tree at depth {depth} with {len(documents)} documents")
        print(f"{'='*80}")
        
        if depth >= self.max_depth or len(documents) < self.min_clusters:
            print(f"✋ Reached max depth or insufficient documents. Creating leaf node.")
            return {
                'depth': depth,
                'documents': documents,
                'summaries': [],
                'clusters': {}
            }
        
        # Embedding
        embed_start = time.time()
        embeddings = self.embed_documents(documents)
        embed_time = time.time() - embed_start
        print(f"⏱️  Embedding time: {embed_time:.2f}秒")
        
        # クラスタリング
        cluster_start = time.time()
        labels, n_clusters = self.cluster_documents(embeddings)
        cluster_time = time.time() - cluster_start
        print(f"⏱️  Clustering time: {cluster_time:.2f}秒")
        
        # クラスタごとに処理
        clusters = {}
        summaries = []
        
        for cluster_id in range(n_clusters):
            cluster_docs = [doc for i, doc in enumerate(documents) if labels[i] == cluster_id]
            print(f"\n📦 Cluster {cluster_id}: {len(cluster_docs)} documents")
            
            if len(cluster_docs) == 0:
                continue
            
            # 要約生成
            summary_text = self.summarize_cluster(cluster_docs)
            summary_doc = Document(
                page_content=summary_text,
                metadata={'cluster_id': cluster_id, 'depth': depth}
            )
            summaries.append(summary_doc)
            
            # 再帰的に子ノードを構築
            children = self.build_tree(cluster_docs, depth + 1)
            clusters[cluster_id] = {
                'summary': summary_doc,
                'documents': cluster_docs,
                'children': children
            }
        
        return {
            'depth': depth,
            'documents': documents,
            'summaries': summaries,
            'clusters': clusters
        }
    
    def search_tree(self, tree: Dict, query: str, top_k: int = 5) -> List[Document]:
        """ツリーを検索"""
        if not tree or 'clusters' not in tree:
            return []
        
        # リーフノード
        if not tree['clusters']:
            docs = tree.get('documents', [])
            if not docs:
                return []
            
            query_embedding = np.array(self.embeddings_model.embed_query(query), dtype=np.float32)
            doc_embeddings = self.embed_documents(docs)
            
            similarities = np.dot(doc_embeddings, query_embedding) / (
                np.linalg.norm(doc_embeddings, axis=1) * np.linalg.norm(query_embedding)
            )
            
            top_indices = np.argsort(similarities)[-top_k:][::-1]
            
            results = []
            for idx in top_indices:
                doc = docs[idx]
                doc.metadata['similarity'] = float(similarities[idx])
                results.append(doc)
            
            return results
        
        # 内部ノード
        summaries = tree.get('summaries', [])
        if not summaries:
            return []
        
        query_embedding = np.array(self.embeddings_model.embed_query(query), dtype=np.float32)
        summary_embeddings = self.embed_documents(summaries)
        
        similarities = np.dot(summary_embeddings, query_embedding) / (
            np.linalg.norm(summary_embeddings, axis=1) * np.linalg.norm(query_embedding)
        )
        
        best_cluster_idx = np.argmax(similarities)
        cluster_id = summaries[best_cluster_idx].metadata['cluster_id']
        
        print(f"Selected cluster {cluster_id} at depth {tree['depth']} (similarity: {similarities[best_cluster_idx]:.4f})")
        
        best_cluster = tree['clusters'][cluster_id]
        return self.search_tree(best_cluster['children'], query, top_k)
    
    def index(self, file_path: str, encoding: str = "utf-8"):
        """ドキュメントをインデックス化"""
        print(f"\n{'='*80}")
        print(f"🚀 RAPTOR Indexing with {self.selection_strategy.upper()}")
        print(f"{'='*80}")
        print(f"📄 File: {file_path}")
        print(f"{'='*80}")
        
        start_time = time.time()
        
        documents = self.load_and_split_documents(file_path, encoding)
        self.tree_structure = self.build_tree(documents)
        
        total_time = time.time() - start_time
        
        print(f"\n{'='*80}")
        print(f"✅ Indexing complete!")
        print(f"   Total time: {total_time:.2f}秒 ({int(total_time//60)}:{int(total_time%60):02d})")
        print(f"{'='*80}")
    
    def retrieve(self, query: str, top_k: int = 5) -> List[Document]:
        """クエリを実行"""
        print(f"\n{'='*80}")
        print(f"🔍 Searching for: '{query}'")
        print(f"{'='*80}")
        
        results = self.search_tree(self.tree_structure, query, top_k)
        
        print(f"✅ Found {len(results)} results")
        
        return results
    
    def save(self, save_dir: str):
        """
        RAGモデルを保存（必要最小限）
        
        保存内容:
        1. tree_structure.json - ツリー構造（要約含む）
        2. stats.json - 統計情報
        3. config.json - 設定パラメータ
        
        Args:
            save_dir: 保存先ディレクトリ
        """
        save_path = Path(save_dir)
        save_path.mkdir(parents=True, exist_ok=True)
        
        print(f"\n{'='*80}")
        print(f"💾 Saving RAPTOR model to: {save_dir}")
        print(f"{'='*80}")
        
        # 1. ツリー構造をJSON形式で保存
        tree_dict = self._tree_to_dict(self.tree_structure)
        with open(save_path / "tree_structure.json", "w", encoding="utf-8") as f:
            json.dump(tree_dict, f, ensure_ascii=False, indent=2)
        print(f"✅ Saved tree_structure.json")
        
        # 2. 統計情報を保存（numpy型をPython標準型に変換）
        stats_serializable = self._make_serializable(self.stats)
        with open(save_path / "stats.json", "w", encoding="utf-8") as f:
            json.dump(stats_serializable, f, ensure_ascii=False, indent=2)
        print(f"✅ Saved stats.json")
        
        # 3. 設定パラメータを保存
        config = {
            'min_clusters': self.min_clusters,
            'max_clusters': self.max_clusters,
            'max_depth': self.max_depth,
            'chunk_size': self.chunk_size,
            'chunk_overlap': self.chunk_overlap,
            'n_iter': self.n_iter,
            'selection_strategy': self.selection_strategy,
            'metric_weights': self.metric_weights
        }
        with open(save_path / "config.json", "w", encoding="utf-8") as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        print(f"✅ Saved config.json")
        
        # ファイルサイズを表示
        total_size = sum(f.stat().st_size for f in save_path.glob("*.json"))
        print(f"\n📊 Total size: {total_size / 1024:.2f} KB")
        print(f"{'='*80}")
    
    def _make_serializable(self, obj):
        """numpy型などをJSON serializable な形式に変換"""
        if isinstance(obj, dict):
            return {k: self._make_serializable(v) for k, v in obj.items()}
        elif isinstance(obj, (list, tuple)):
            return [self._make_serializable(item) for item in obj]
        elif isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        else:
            return obj
    
    def _tree_to_dict(self, node: Dict) -> Dict:
        """ツリー構造をJSON serializable な辞書に変換"""
        result = {
            'depth': node.get('depth', 0),
            'summaries': [],
            'documents': [],  # ドキュメント内容も保存
            'clusters': {}
        }
        
        # 要約を文字列化
        summaries = node.get('summaries', [])
        for summary in summaries:
            if isinstance(summary, Document):
                result['summaries'].append({
                    'content': summary.page_content,
                    'metadata': summary.metadata
                })
            else:
                result['summaries'].append({'content': str(summary), 'metadata': {}})
        
        # ドキュメント内容も保存（完全な検索のため）
        documents = node.get('documents', [])
        for doc in documents:
            if isinstance(doc, Document):
                result['documents'].append({
                    'content': doc.page_content,
                    'metadata': doc.metadata
                })
            else:
                result['documents'].append({'content': str(doc), 'metadata': {}})
        
        # 子ノードを再帰的に変換
        clusters = node.get('clusters', {})
        for cluster_id, cluster_data in clusters.items():
            result['clusters'][str(cluster_id)] = {
                'summary': self._doc_to_dict(cluster_data.get('summary')),
                'documents': [],  # 子ノードのdocumentsはchildrenに含まれる
                'children': self._tree_to_dict(cluster_data['children']) if 'children' in cluster_data else {}
            }
        
        return result
    
    def _doc_to_dict(self, doc) -> Optional[Dict]:
        """Documentオブジェクトを辞書に変換"""
        if doc is None:
            return None
        if isinstance(doc, Document):
            return {
                'content': doc.page_content,
                'metadata': doc.metadata
            }
        return {'content': str(doc), 'metadata': {}}
    
    @classmethod
    def load(cls, save_dir: str, embeddings_model, llm):
        """
        保存されたRAGモデルを読み込み
        
        Args:
            save_dir: 保存先ディレクトリ
            embeddings_model: Embeddings model
            llm: LLM for summarization
            
        Returns:
            RAPTORRetrieverEval インスタンス
        """
        save_path = Path(save_dir)
        
        print(f"\n{'='*80}")
        print(f"📂 Loading RAPTOR model from: {save_dir}")
        print(f"{'='*80}")
        
        # 設定を読み込み
        with open(save_path / "config.json", "r", encoding="utf-8") as f:
            config = json.load(f)
        print(f"✅ Loaded config.json")
        
        # インスタンスを作成
        instance = cls(
            embeddings_model=embeddings_model,
            llm=llm,
            **config
        )
        
        # ツリー構造を読み込み
        with open(save_path / "tree_structure.json", "r", encoding="utf-8") as f:
            tree_dict = json.load(f)
        instance.tree_structure = instance._dict_to_tree(tree_dict)
        print(f"✅ Loaded tree_structure.json")
        
        # 統計情報を読み込み
        with open(save_path / "stats.json", "r", encoding="utf-8") as f:
            instance.stats = json.load(f)
        print(f"✅ Loaded stats.json")
        
        print(f"{'='*80}")
        print(f"✅ Model loaded successfully!")
        print(f"{'='*80}")
        
        return instance
    
    def _dict_to_tree(self, tree_dict: Dict) -> Dict:
        """辞書からツリー構造を復元"""
        result = {
            'depth': tree_dict.get('depth', 0),
            'summaries': [],
            'documents': [],  # ドキュメントも復元
            'clusters': {}
        }
        
        # 要約をDocumentオブジェクトに復元
        for summary_dict in tree_dict.get('summaries', []):
            doc = Document(
                page_content=summary_dict['content'],
                metadata=summary_dict.get('metadata', {})
            )
            result['summaries'].append(doc)
        
        # ドキュメントをDocumentオブジェクトに復元
        for doc_dict in tree_dict.get('documents', []):
            doc = Document(
                page_content=doc_dict['content'],
                metadata=doc_dict.get('metadata', {})
            )
            result['documents'].append(doc)
        
        # 子ノードを再帰的に復元
        clusters = tree_dict.get('clusters', {})
        for cluster_id, cluster_data in clusters.items():
            summary_dict = cluster_data.get('summary')
            summary_doc = None
            if summary_dict:
                summary_doc = Document(
                    page_content=summary_dict['content'],
                    metadata=summary_dict.get('metadata', {})
                )
            
            # childrenが空でない場合のみ再帰的に復元
            children_data = cluster_data.get('children')
            if children_data and children_data.get('clusters'):
                # 内部ノード
                children = self._dict_to_tree(children_data)
            elif children_data:
                # リーフノード：childrenのdocumentsを持つ
                children = self._dict_to_tree(children_data)
            else:
                # childrenなし
                children = {}
            
            result['clusters'][int(cluster_id)] = {
                'summary': summary_doc,
                'documents': [],  # 子ノードのdocumentsはchildrenに含まれる
                'children': children
            }
        
        return result
