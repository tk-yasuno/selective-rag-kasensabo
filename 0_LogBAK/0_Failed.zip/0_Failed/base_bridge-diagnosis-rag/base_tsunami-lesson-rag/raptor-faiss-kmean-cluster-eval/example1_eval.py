"""
Example 1: 評価指標比較テスト

6つの評価戦略を比較:
- Silhouette Score (推奨)
- Davies-Bouldin Index
- Calinski-Harabasz Index
- BIC (従来手法)
- AIC (従来手法)
- Combined (複数指標の組み合わせ)

データセット: test.txt (864チャンク)
"""

from langchain_ollama import OllamaEmbeddings, ChatOllama
from raptor_eval import RAPTORRetrieverEval
import time

# モデル設定
embeddings = OllamaEmbeddings(model="mxbai-embed-large")
llm = ChatOllama(model="granite-code:8b", temperature=0)

# テストクエリ
test_queries = [
    "RAGシステムの主要な構成要素は何ですか？",
    "検索性能を向上させる方法について教えてください",
    "大規模言語モデルの課題は何ですか？"
]

# 評価戦略リスト
# Combined戦略: 実験結果からCHI除外（k=2バイアス回避）
strategies = [
    ('silhouette', 'Silhouette Score', None),
    ('dbi', 'Davies-Bouldin Index', None),
    ('chi', 'Calinski-Harabasz Index', None),
    ('bic', 'BIC (Bayesian Information Criterion)', None),
    ('aic', 'AIC (Akaike Information Criterion)', None),
    ('combined', 'Combined (Sil+DBI)', {'silhouette': 0.5, 'dbi': 0.5, 'chi': 0.0})
]

results = []

print("="*100)
print("🧪 Example 1: 評価指標比較テスト (test.txt)")
print("="*100)
print(f"📊 評価戦略: {len(strategies)}種類")
print(f"🔍 テストクエリ: {len(test_queries)}個")
print("="*100)

for strategy_key, strategy_name, weights in strategies:
    print(f"\n\n{'#'*100}")
    print(f"# Strategy: {strategy_name}")
    print(f"{'#'*100}")
    
    # Retriever初期化
    retriever = RAPTORRetrieverEval(
        embeddings_model=embeddings,
        llm=llm,
        min_clusters=2,
        max_clusters=5,
        max_depth=3,
        chunk_size=800,
        chunk_overlap=200,
        selection_strategy=strategy_key,
        metric_weights=weights
    )
    
    # インデックス構築
    build_start = time.time()
    retriever.index('../test.txt', encoding='utf-8')
    build_time = time.time() - build_start
    
    # クエリテスト
    query_start = time.time()
    all_results = []
    for query in test_queries:
        docs = retriever.retrieve(query, top_k=3)
        all_results.extend(docs)
    query_time = time.time() - query_start
    
    # 結果集計
    selections = retriever.stats['selections']
    avg_k = sum(selections) / len(selections) if selections else 0
    
    if retriever.stats['silhouette_scores']:
        avg_sil = sum(retriever.stats['silhouette_scores']) / len(retriever.stats['silhouette_scores'])
    else:
        avg_sil = 0
    
    if retriever.stats['dbi_scores']:
        avg_dbi = sum(retriever.stats['dbi_scores']) / len(retriever.stats['dbi_scores'])
    else:
        avg_dbi = 0
    
    if retriever.stats['chi_scores']:
        avg_chi = sum(retriever.stats['chi_scores']) / len(retriever.stats['chi_scores'])
    else:
        avg_chi = 0
    
    # 類似度スコア
    similarities = [doc.metadata.get('similarity', 0) for doc in all_results if 'similarity' in doc.metadata]
    avg_similarity = sum(similarities) / len(similarities) if similarities else 0
    
    result = {
        'strategy': strategy_name,
        'strategy_key': strategy_key,
        'build_time': build_time,
        'query_time': query_time,
        'avg_k': avg_k,
        'selections': selections,
        'avg_silhouette': avg_sil,
        'avg_dbi': avg_dbi,
        'avg_chi': avg_chi,
        'avg_similarity': avg_similarity,
        'weights': weights
    }
    
    results.append(result)
    
    print(f"\n{'='*100}")
    print(f"📊 {strategy_name} - 結果サマリ")
    print(f"{'='*100}")
    print(f"⏱️  Build time: {build_time:.2f}秒")
    print(f"⏱️  Query time: {query_time:.2f}秒 ({query_time/len(test_queries):.2f}秒/クエリ)")
    print(f"📈 平均クラスタ数: {avg_k:.2f}")
    print(f"📈 クラスタ数履歴: {selections}")
    print(f"📊 平均 Silhouette: {avg_sil:.4f}")
    print(f"📊 平均 DBI: {avg_dbi:.4f}")
    print(f"📊 平均 CHI: {avg_chi:.2f}")
    print(f"🎯 平均類似度: {avg_similarity:.4f}")
    print(f"{'='*100}")

# 最終比較
print(f"\n\n{'#'*100}")
print(f"# 最終比較: 全6戦略")
print(f"{'#'*100}")

print(f"\n{'='*100}")
print(f"⏱️  ビルド時間比較")
print(f"{'='*100}")
for r in results:
    print(f"{r['strategy']:40s}: {r['build_time']:7.2f}秒")

print(f"\n{'='*100}")
print(f"⏱️  クエリ時間比較")
print(f"{'='*100}")
for r in results:
    print(f"{r['strategy']:40s}: {r['query_time']:7.2f}秒 ({r['query_time']/len(test_queries):.2f}秒/クエリ)")

print(f"\n{'='*100}")
print(f"📈 平均クラスタ数比較")
print(f"{'='*100}")
for r in results:
    print(f"{r['strategy']:40s}: {r['avg_k']:.2f} {r['selections']}")

print(f"\n{'='*100}")
print(f"📊 評価指標比較")
print(f"{'='*100}")
print(f"{'Strategy':40s} {'Silhouette':>12s} {'DBI':>12s} {'CHI':>12s}")
print(f"{'-'*80}")
for r in results:
    print(f"{r['strategy']:40s} {r['avg_silhouette']:12.4f} {r['avg_dbi']:12.4f} {r['avg_chi']:12.2f}")

print(f"\n{'='*100}")
print(f"🎯 平均類似度比較 (高いほど良い)")
print(f"{'='*100}")
sorted_by_similarity = sorted(results, key=lambda x: x['avg_similarity'], reverse=True)
for i, r in enumerate(sorted_by_similarity, 1):
    print(f"{i}. {r['strategy']:40s}: {r['avg_similarity']:.4f}")

print(f"\n{'='*100}")
print(f"🏆 推奨戦略")
print(f"{'='*100}")

# クエリ速度トップ
fastest_query = min(results, key=lambda x: x['query_time'])
print(f"⚡ 最速クエリ: {fastest_query['strategy']} ({fastest_query['query_time']:.2f}秒)")

# 類似度トップ
best_similarity = max(results, key=lambda x: x['avg_similarity'])
print(f"🎯 最高精度: {best_similarity['strategy']} (類似度={best_similarity['avg_similarity']:.4f})")

# バランス重視（クエリ速度と類似度の積）
for r in results:
    r['balance_score'] = r['avg_similarity'] / (r['query_time'] + 1e-6)
best_balance = max(results, key=lambda x: x['balance_score'])
print(f"⚖️  バランス: {best_balance['strategy']} (スコア={best_balance['balance_score']:.4f})")

print(f"\n{'='*100}")
print(f"✅ Example 1 完了")
print(f"{'='*100}")
