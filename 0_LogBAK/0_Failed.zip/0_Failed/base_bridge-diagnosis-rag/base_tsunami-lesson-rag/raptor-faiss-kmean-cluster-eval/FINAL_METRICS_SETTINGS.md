# 最終評価指標設定

**決定日**: 2025年10月18日  
**バージョン**: Final v1.0  
**ステータス**: 本番環境推奨設定

---

## 📊 最終決定: Evaluation Metrics の重み設定

### 採用した設定

```python
metric_weights = {
    'silhouette': 0.5,  # クラスタ品質（ミクロ視点）
    'dbi': 0.5,         # クラスタ分離度（マクロ視点）
    'chi': 0.0          # CHI除外（k=2バイアス回避）
}
```

---

## 🔬 決定の根拠

### 実験1の結果（test.txt, 864チャンク）

**従来のBIC/AIC手法:**
- BIC, AIC, Hybrid, Weighted: 全てk=2を選択
- Elbowのみk=3を選択（2倍高速、5%精度低下）

**教訓:**
- BIC/AICはモデル複雑度のペナルティが強すぎる
- クラスタの品質を直接評価する指標が必要

---

### 実験2の結果（rag_survey.txt, 631チャンク）

**Combined戦略テスト（旧設定: Sil 0.3, DBI 0.4, CHI 0.3）:**

| Depth | Docs | 選択k | Sil最適 | DBI最適 | CHI最適 | 結果 |
|-------|------|-------|---------|---------|---------|------|
| 0 | 631 | k=2 | k=4 | k=5 | k=2 | CHI優勢 |
| 1-0 | 264 | k=2 | k=2 | k=5 | k=2 | 一致 |
| **1-1** | **367** | **k=3** | **k=5** | **k=5** | **k=2** | **✅ 成功** |
| 2-0 | 198 | k=2 | k=2 | k=2 | k=2 | 一致 |
| 2-1 | 66 | k=2 | k=2 | k=4 | k=2 | 警告あり |
| 2-2 | 123 | k=2 | k=2 | k=2 | k=2 | 一致 |

**結果: 7回中6回がk=2、1回のみk=3**

---

### CHIの問題点

#### 問題1: 構造的なk=2バイアス

**Calinski-Harabasz Index の定義:**
```
CHI = [SS_between / (k-1)] / [SS_within / (n-k)]
```

- k=2の場合: `(k-1) = 1` → 分母が最小 → CHI最大
- k=5の場合: `(k-1) = 4` → 分母が大きい → CHI減少

**実測データ（Depth 0, 631 docs）:**
```
CHI: 58.86 (k=2) → 43.38 (k=3) → 36.71 (k=4) → 30.28 (k=5)
k=2とk=5の差: 1.9倍
```

#### 問題2: 正規化後の支配的影響

```python
# 正規化後のスコア
chi_norm = [1.0, 0.46, 0.23, 0.0]  # k=2が完全に1.0

# Combined score への貢献
0.3 * chi_norm[k=2] = 0.3 * 1.0 = 0.3
0.3 * chi_norm[k=5] = 0.3 * 0.0 = 0.0

# 30%の重みでも、k=2方向に強く引っ張る
```

#### 問題3: Silhouette/DBIとの矛盾

**唯一の成功例（Depth 1, Branch 1, 367 docs）:**
```
Silhouette: k=5 を推奨 (0.0698)
DBI:        k=5 を推奨 (2.9977)
CHI:        k=2 を推奨 (21.72)

→ Combined戦略が妥協点のk=3を選択
```

この例では、CHIが他の2指標と真逆の推奨をしています。

---

### Silhouette と DBI の相補性

#### Silhouette Score の特徴

**評価対象:**
- 各データポイントが適切なクラスタに属しているか
- ミクロな視点（個々のデータポイント）

**計算式:**
```
s(i) = (b(i) - a(i)) / max(a(i), b(i))
```
- a(i): 同一クラスタ内の平均距離
- b(i): 最も近い他クラスタとの平均距離

**範囲:** -1 〜 +1（大きいほど良い）

**長所:**
- クラスタの品質を直接評価
- 各点の適切性を測定

**短所:**
- 計算量 O(n²)（大規模データで遅い）

---

#### Davies-Bouldin Index の特徴

**評価対象:**
- クラスタ間の分離度
- マクロな視点（クラスタ全体）

**計算式:**
```
DBI = (1/k) * Σ max_j [(s_i + s_j) / d(c_i, c_j)]
```
- s_i: クラスタiの平均クラスタ内距離
- d(c_i, c_j): クラスタ中心間の距離

**範囲:** 0 〜 ∞（小さいほど良い）

**長所:**
- クラスタ間の類似度を評価
- 計算量 O(n*k)（軽量）

**短所:**
- 値の範囲が広い（2.5 - 4.8）
- 解釈がやや難しい

---

#### なぜ相補的なのか

| 観点 | Silhouette | DBI |
|------|-----------|-----|
| 評価単位 | データポイント | クラスタ |
| 視点 | ミクロ | マクロ |
| 計算量 | O(n²) | O(n*k) |
| 推奨傾向 | k=4〜5 | k=5 |

**実証データ（Depth 1, Branch 1, 367 docs）:**
```
          k=2    k=3    k=4    k=5
Sil:    0.0548  0.0642  0.0595  0.0698  → k=5推奨
DBI:    4.0739  3.3763  3.3123  2.9977  → k=5推奨
CHI:   21.72   21.28   18.33   17.13    → k=2推奨

両者が一致してk=5を推奨！
```

**結論:**
SilhouetteとDBIは異なる視点から評価するが、結論は一致しやすい（相補的）

---

## 💡 新設定の期待効果

### 期待1: より多様なクラスタ数の選択

**旧設定（CHI 30%）:**
- 7回中6回がk=2（86%）
- 1回のみk=3（14%）

**新設定（CHI 0%）:**
- k=3, k=4, k=5の選択が増加
- より細かい階層構造

---

### 期待2: Silhouette/DBIの一致時は明確な選択

**例: Depth 1, Branch 1 (367 docs)**

旧設定:
```
Sil推奨k=5 (0.5) + DBI推奨k=5 (0.4) + CHI推奨k=2 (0.3) = k=3
```

新設定:
```
Sil推奨k=5 (0.5) + DBI推奨k=5 (0.5) + CHI推奨k=2 (0.0) = k=5
```

→ より明確にk=5を選択

---

### 期待3: 計算量の削減

CHIの計算が不要になるため、わずかに高速化

```python
# 計算が不要
if self.metric_weights.get('chi', 0) == 0:
    chi_scores = [0] * (max_k - min_k + 1)  # スキップ
```

---

## 🚀 使用方法

### デフォルト設定（推奨）

```python
from raptor_eval import RAPTORRetrieverEval

retriever = RAPTORRetrieverEval(
    embeddings_model=embeddings,
    llm=llm,
    selection_strategy='combined',  # デフォルトで Sil 0.5, DBI 0.5, CHI 0.0
    min_clusters=2,
    max_clusters=7
)
```

---

### カスタマイズ例1: Silhouette重視

```python
retriever = RAPTORRetrieverEval(
    embeddings_model=embeddings,
    llm=llm,
    selection_strategy='combined',
    metric_weights={
        'silhouette': 0.6,  # 精度最優先
        'dbi': 0.4,
        'chi': 0.0
    }
)
```

---

### カスタマイズ例2: DBI重視

```python
retriever = RAPTORRetrieverEval(
    embeddings_model=embeddings,
    llm=llm,
    selection_strategy='combined',
    metric_weights={
        'silhouette': 0.4,
        'dbi': 0.6,  # 速度とバランス
        'chi': 0.0
    }
)
```

---

### カスタマイズ例3: CHIを少量含める（実験的）

```python
retriever = RAPTORRetrieverEval(
    embeddings_model=embeddings,
    llm=llm,
    selection_strategy='combined',
    metric_weights={
        'silhouette': 0.4,
        'dbi': 0.5,
        'chi': 0.1  # わずかに含める
    }
)
```

---

## 📈 他の戦略との比較

### 単一指標戦略

| 戦略 | 用途 | 長所 | 短所 |
|------|------|------|------|
| `silhouette` | 精度最優先 | 最高品質 | O(n²)で遅い |
| `dbi` | バランス | 軽量で実用的 | 解釈が難しい |
| `chi` | 速度優先 | 最も軽量 | k=2バイアス |
| `bic`/`aic` | 比較用 | 従来手法 | 保守的すぎる |

### Combined戦略の優位性

**利点:**
- 複数視点でバランスの取れた評価
- Silhouette（ミクロ）+ DBI（マクロ）で相補的
- CHI除外でk=2バイアスを回避

**推奨度:**
```
🥇 Combined (Sil 0.5, DBI 0.5, CHI 0.0)  ← 本設定
🥈 Silhouette のみ（精度重視）
🥉 DBI のみ（バランス）
```

---

## 🎯 データサイズ別の推奨設定

### 小規模データ (< 1,000チャンク)

```python
selection_strategy='combined'
metric_weights={'silhouette': 0.5, 'dbi': 0.5, 'chi': 0.0}
min_clusters=2
max_clusters=7
max_depth=3
```

---

### 中規模データ (1,000-10,000チャンク)

```python
selection_strategy='combined'
metric_weights={'silhouette': 0.4, 'dbi': 0.6, 'chi': 0.0}
min_clusters=3  # k=2を避ける
max_clusters=10
max_depth=3
chunk_size=1000  # チャンク数削減
```

---

### 大規模データ (> 10,000チャンク)

```python
selection_strategy='dbi'  # 単一指標で高速化
min_clusters=3
max_clusters=8
max_depth=2  # 深さ制限
chunk_size=1200
```

Silhouetteは O(n²) で実用不可のため、DBIのみ使用

---

## 📝 まとめ

### 最終決定

```python
metric_weights = {
    'silhouette': 0.5,
    'dbi': 0.5,
    'chi': 0.0
}
```

### 決定理由

1. **CHIのk=2バイアス除去**
   - 構造的な問題（(k-1)が分母）
   - 正規化後も支配的影響
   
2. **Silhouette + DBI の相補性**
   - ミクロ（データポイント）+ マクロ（クラスタ）
   - 実験で両者が一致（k=5推奨）
   
3. **実験結果の裏付け**
   - 旧設定: 7回中6回がk=2（86%）
   - 新設定: より多様な選択を期待

### 期待される改善

- ✅ k=3, k=4, k=5 の選択増加
- ✅ より細かい階層構造
- ✅ 高品質なクラスタリング
- ✅ わずかな高速化（CHI計算不要）

### 今後の検証

1. Example 1, 2 を新設定で再実行
2. k値の分布を確認
3. クエリ精度（類似度スコア）を比較
4. 本番環境での検証

---

**作成日**: 2025年10月18日  
**バージョン**: Final v1.0  
**承認者**: 実験結果に基づく最終決定  
**ステータス**: 本番環境推奨設定
