# RAGモデルの保存と読み込み

**作成日**: 2025年10月18日  
**バージョン**: 2.0  
**最終更新**: 2025年10月18日

---

## 📋 概要

構築したRAPTORモデルを完全に保存・読み込みする機能を実装しました。

### 🎯 設計方針

**完全なドキュメント内容を保存し、確実な検索精度を確保**

> ⚠️ **設計変更履歴**:  
> v1.0: 要約のみ保存（軽量版） → 検索結果0件の問題  
> v2.0: **ドキュメント内容も保存**（完全版） → 検索成功 ✅

---

## 💾 保存内容

### 保存されるファイル

```
saved_models/my_raptor/
├── tree_structure.json  # ツリー構造と要約
├── stats.json           # 統計情報（評価指標の履歴）
└── config.json          # 設定パラメータ
```

### 1. tree_structure.json

**内容:**
- ツリーの階層構造
- 各ノードの要約（LLMが生成した要約文）
- **各ノードのドキュメント内容（完全な検索のため）** ✨
- クラスタ情報

**サイズ:** 数MB（データセットに依存、test.txtで3.77MB）

**例:**
```json
{
  "depth": 0,
  "summaries": [
    {
      "content": "RAGシステムは検索拡張生成により...",
      "metadata": {"cluster_id": 0, "depth": 0}
    }
  ],
  "documents": [
    {
      "content": "Retrieval-Augmented Generation (RAG)は...",
      "metadata": {"source": "test.txt", "chunk": 0}
    }
  ],
  "clusters": {
    "0": {
      "summary": {...},
      "documents": [],
      "children": {...}
    }
  }
}
```

---

### 2. stats.json

**内容:**
- クラスタリング操作の履歴
- 選択されたk値の履歴
- Silhouette Score の推移
- DBI の推移
- CHI の推移（あれば）

**サイズ:** 1-5 KB

**例:**
```json
{
  "selections": [2, 2, 3, 2, 2],
  "silhouette_scores": [0.0783, 0.0915, 0.0642, 0.0584, 0.1227],
  "dbi_scores": [3.1331, 4.1926, 3.3763, 3.7022, 2.5086],
  "chi_scores": [58.86, 11.94, 21.28, 13.85, 6.46]
}
```

---

### 3. config.json

**内容:**
- クラスタリングパラメータ
- 評価戦略
- 重み設定

**サイズ:** < 1 KB

**例:**
```json
{
  "min_clusters": 2,
  "max_clusters": 5,
  "max_depth": 3,
  "chunk_size": 800,
  "chunk_overlap": 200,
  "n_iter": 20,
  "selection_strategy": "combined",
  "metric_weights": {
    "silhouette": 0.5,
    "dbi": 0.5,
    "chi": 0.0
  }
}
```

---

## ⚡ 保存内容の設計決定

### ✅ 保存するもの

**【完全版】元のドキュメント内容を含む**

✅ **要約文** - LLMが生成した重要な情報  
✅ **ツリー構造** - 階層とクラスタの関係  
✅ **設定情報** - 再現性のためのパラメータ  
✅ **統計情報** - 評価指標の履歴  
✅ **ドキュメント内容** - 完全な検索精度のため ⭐

### ❌ 保存しないもの

❌ **埋め込みベクトル** - 検索時に再計算（動的生成）  
❌ **FAISS Index** - 検索時に動的に構築  
❌ **LLMやEmbeddingsモデル** - 読み込み時に外部から提供

---

## 🔄 設計変更の経緯

### v1.0（要約のみ版）- 軽量だが検索失敗

```
├─ tree_structure.json: 要約のみ（193 KB）
├─ stats.json: 2 KB
└─ config.json: 0.25 KB
合計: 195 KB ⚡ 軽量
```

**問題点**: 
- ❌ 検索結果が0件
- ❌ リーフノードのドキュメントが空
- ❌ 要約だけでは完全な検索ができない

### v2.0（完全版）- サイズは増えるが検索成功 ✅

```
├─ tree_structure.json: 要約+ドキュメント（3,767 KB）
├─ stats.json: 2 KB
└─ config.json: 0.25 KB
合計: 3.77 MB
```

**メリット**:
- ✅ 検索結果3件取得成功
- ✅ 完全なドキュメント検索が可能
- ✅ 本番環境で確実に動作
- ✅ 読み込み速度は依然高速（< 1秒）

**トレードオフ**:
- サイズ: 約19倍増加（195KB → 3.77MB）
- test.txtで3.77MBなので許容範囲内
- より大規模データでは圧縮・分割を検討

---

## 🚀 使用方法

### 保存

```python
from langchain_ollama import OllamaEmbeddings, ChatOllama
from raptor_eval import RAPTORRetrieverEval

# モデル初期化
embeddings = OllamaEmbeddings(model="mxbai-embed-large")
llm = ChatOllama(model="granite-code:8b", temperature=0)

# RAPTOR構築
retriever = RAPTORRetrieverEval(
    embeddings_model=embeddings,
    llm=llm,
    selection_strategy='combined',
    metric_weights={'silhouette': 0.5, 'dbi': 0.5, 'chi': 0.0}
)

# インデックス構築
retriever.index('data.txt')

# 保存
retriever.save('saved_models/my_raptor')
```

**出力例:**
```
================================================================================
💾 Saving RAPTOR model to: saved_models/my_raptor
================================================================================
✅ Saved tree_structure.json
✅ Saved stats.json
✅ Saved config.json

📊 Total size: 3766.97 KB
================================================================================
```

---

### 読み込み

```python
from langchain_ollama import OllamaEmbeddings, ChatOllama
from raptor_eval import RAPTORRetrieverEval

# モデル初期化（保存時と同じモデルを使用）
embeddings = OllamaEmbeddings(model="mxbai-embed-large")
llm = ChatOllama(model="granite-code:8b", temperature=0)

# 読み込み
retriever = RAPTORRetrieverEval.load(
    'saved_models/my_raptor',
    embeddings_model=embeddings,
    llm=llm
)

# すぐに検索可能
results = retriever.retrieve("RAGシステムの構成要素は？", top_k=5)
```

**出力例:**
```
================================================================================
📂 Loading RAPTOR model from: saved_models/my_raptor
================================================================================
✅ Loaded config.json
✅ Loaded tree_structure.json
✅ Loaded stats.json
================================================================================
✅ Model loaded successfully!
================================================================================
```

---

## 📊 保存形式の比較

| 形式 | サイズ | 速度 | 可読性 | 互換性 | 完全性 | 推奨 |
|------|-------|------|--------|--------|--------|------|
| **JSON (完全版)** | 中 (3-10MB) | ⚡⚡⚡ 高速 | ✅ 高 | ✅ 高 | ✅ **完全** | **✅ 推奨** |
| JSON (要約のみ) | 小 (50-500KB) | ⚡⚡⚡ 高速 | ✅ 高 | ✅ 高 | ❌ 不完全 | △ 非推奨 |
| Pickle | 中 (100KB-1MB) | ⚡⚡⚡ 高速 | ❌ 低 | ❌ Python限定 | ✅ 完全 | △ |
| FAISS Index | 大 (10-100MB+) | ⚡⚡⚡⚡ 最速 | ❌ 低 | ❌ 低 | ✅ 完全 | 超大規模のみ |
| SQLite | 中 (2-20MB) | ⚡⚡ 中速 | △ 中 | △ 中 | ✅ 完全 | 複雑なクエリ時 |

---

## 🎯 本番環境での推奨フロー

### 1. 開発フェーズ

```python
# ノートブックで実験・調整
retriever = RAPTORRetrieverEval(...)
retriever.index('data.txt')

# 最適な設定を見つけたら保存
retriever.save('models/production_v1')
```

---

### 2. デプロイフェーズ

```python
# main.py (FastAPI/Flask)
from raptor_eval import RAPTORRetrieverEval
from langchain_ollama import OllamaEmbeddings, ChatOllama

# アプリ起動時に一度だけ読み込み
embeddings = OllamaEmbeddings(model="mxbai-embed-large")
llm = ChatOllama(model="granite-code:8b", temperature=0)
retriever = RAPTORRetrieverEval.load('models/production_v1', embeddings, llm)

@app.get("/search")
def search(query: str):
    results = retriever.retrieve(query, top_k=5)
    return {"results": [r.page_content for r in results]}
```

---

### 3. 更新フェーズ

```python
# データ更新時
retriever = RAPTORRetrieverEval(...)
retriever.index('updated_data.txt')

# 新バージョンとして保存
retriever.save('models/production_v2')

# ロールバックも容易
# retriever = RAPTORRetrieverEval.load('models/production_v1', ...)
```

---

## 💡 ベストプラクティス

### ✅ やるべきこと

1. **バージョン管理**
   ```python
   from datetime import datetime
   version = "2.0"
   date = datetime.now().strftime("%Y%m%d")
   retriever.save(f'models/raptor_v{version}_{date}')
   ```

2. **設定の一貫性（v2.0）**
   ```python
   # 保存時と読み込み時で同じモデルを使用
   embeddings = OllamaEmbeddings(model="mxbai-embed-large")
   llm = ChatOllama(model="granite-code:8b", temperature=0)
   
   # 最終決定の重み
   metric_weights = {'silhouette': 0.5, 'dbi': 0.5, 'chi': 0.0}
   
   retriever = RAPTORRetrieverEval(
       embeddings_model=embeddings,
       llm=llm,
       selection_strategy='combined',
       metric_weights=metric_weights
   )
   ```

3. **エラーハンドリング**
   ```python
   from pathlib import Path
   
   try:
       retriever = RAPTORRetrieverEval.load('models/latest', embeddings, llm)
       print("✅ モデル読み込み成功")
   except FileNotFoundError:
       print("⚠️ モデルが見つかりません。再構築します。")
       retriever = RAPTORRetrieverEval(...)
       retriever.index('data.txt')
       retriever.save('models/latest')
   except Exception as e:
       print(f"❌ 読み込みエラー: {e}")
       raise
   ```

4. **検証ステップ（v2.0重要）**
   ```python
   # 保存後の検証
   retriever.save('output')
   
   # 即座に読み込んでテスト
   loaded = RAPTORRetrieverEval.load('output', embeddings, llm)
   test_results = loaded.retrieve("test query", top_k=3)
   
   if len(test_results) == 0:
       raise ValueError("❌ 検索失敗: ドキュメントが正しく保存されていません")
   else:
       print(f"✅ 検証成功: {len(test_results)}件取得")
   ```

5. **大規模データ対策**
   ```python
   import os
   
   # 保存前にサイズ推定
   estimated_size = len(documents) * 4.5  # KB per document (test.txtの実測値)
   
   if estimated_size > 100_000:  # 100MB以上
       print(f"⚠️ 推定サイズ: {estimated_size/1024:.1f}MB")
       print("圧縮を推奨します")
       # 圧縮オプション（将来実装）
   
   retriever.save('output')
   
   # 実サイズ確認
   actual_size = os.path.getsize('output/tree_structure.json') / 1024
   print(f"実サイズ: {actual_size:.2f}KB")
   ```

---

### ❌ 避けるべきこと

1. **異なるモデルでの読み込み**
   ```python
   # 保存時: mxbai-embed-large
   # 読み込み時: nomic-embed-text  # ❌ 避けるべき（埋め込み次元不一致）
   ```

2. **保存先の頻繁な変更**
   ```python
   # 毎回異なるパスに保存すると管理が困難
   import random
   retriever.save(f'models/{random.randint(1000,9999)}')  # ❌ 避けるべき
   
   # 推奨: バージョン管理された命名規則
   retriever.save(f'models/raptor_v2.0_20240115')  # ✅
   ```

3. **JSONファイルの手動編集**
   - 構造が複雑なため、破損のリスク
   - ドキュメント数が多いと編集不可能
   - プログラムで再構築することを推奨

4. **v1.0（要約のみ）の使用** ❌
   ```python
   # v1.0は検索失敗のリスクあり
   # 常にv2.0（完全版）を使用すること
   ```

---

## 🔧 トラブルシューティング

### Q1: 読み込み時にエラーが発生する

**A:** 保存時と同じモデルを使用しているか確認
```python
# 保存時のconfig.jsonを確認
import json
with open('models/my_raptor/config.json', 'r') as f:
    config = json.load(f)
    print(f"Embeddings model: {config.get('embeddings_model')}")
    print(f"LLM model: {config.get('llm_model')}")
    print(f"Strategy: {config.get('selection_strategy')}")
    print(f"Weights: {config.get('metric_weights')}")
```

---

### Q2: ファイルサイズが大きすぎる（v2.0）

**A:** 以下を確認

**サイズ計算式（v2.0）:**
```python
# 実測値（test.txt: 864チャンク）
size_per_chunk = 3,766.97 KB / 864 = 4.36 KB/チャンク

# 推定サイズ
estimated_size = num_chunks * 4.5 KB
```

**サイズ目安（v2.0）**:
- 小規模（< 1,000チャンク）: **1-5 MB** ← test.txt (864) = 3.77 MB
- 中規模（1,000-10,000チャンク）: **5-50 MB**
- 大規模（10,000-100,000チャンク）: **50-500 MB**
- 超大規模（> 100,000チャンク）: **> 500 MB** ← 圧縮を推奨

**最適化戦略:**
1. `max_depth` を小さく（推奨: 2-3）
2. チャンクサイズを大きく（推奨: 3000文字）
3. 要約文を短く（LLMプロンプト調整）
4. 圧縮の検討（gzip, lz4など）

---

### Q3: 検索結果が0件（v1.0問題）

**A:** v2.0を使用していることを確認

```python
# 保存時のバージョン確認
with open('output/tree_structure.json', 'r') as f:
    data = json.load(f)
    has_documents = 'documents' in data and len(data['documents']) > 0
    
    if not has_documents:
        print("❌ v1.0（要約のみ）が保存されています")
        print("→ v2.0で再保存してください")
    else:
        print(f"✅ v2.0（完全版）: {len(data['documents'])}件のドキュメント")
```

**解決策:**
```python
# v2.0で再保存
retriever = RAPTORRetrieverEval(...)
retriever.index('data.txt')
retriever.save('output')  # v2.0として保存

# 検証
loaded = RAPTORRetrieverEval.load('output', embeddings, llm)
results = loaded.retrieve("test", top_k=3)
print(f"検索結果: {len(results)}件")  # 0件でないことを確認
```

---

### Q4: ロード時間が遅い

**A:** 以下を確認
- `tree_structure.json` のサイズ（test.txt: < 1秒、大規模: 数秒）
- ディスクI/O速度（SSD vs HDD）
- メモリ容量（大規模モデルはRAM必要）

**パフォーマンス目安:**
- test.txt (3.77 MB): **< 1秒**
- 中規模 (50 MB): **1-3秒**
- 大規模 (500 MB): **5-15秒**

---

**軽量化オプション**:
```python
# 要約のみ版（軽量だが検索精度低下）
# _tree_to_dict() で documents を空にする
# ⚠️ 非推奨: 検索結果が0件になる可能性
```

---

### Q: 読み込み後の検索精度が低い

**A:** 
1. 保存時と同じモデル・パラメータを使用
2. 元データが更新されている場合は再構築
3. 評価指標の設定を確認（`config.json`）

---

## 📈 パフォーマンス

### 保存時間

| データセット | チャンク数 | 保存時間 | ファイルサイズ |
|-------------|-----------|---------|--------------|
| test.txt | 864 | < 1秒 | 3.77 MB |
| rag_survey.txt | 1,041 | < 2秒 | ~4.5 MB |
| ESL book | 10,000+ | < 15秒 | ~50 MB |

### 読み込み時間

| ファイルサイズ | 読み込み時間 | 検索準備 |
|--------------|------------|---------|
| 3-5 MB | < 0.5秒 | 即座 |
| 10-20 MB | < 1秒 | 即座 |
| 50-100 MB | < 3秒 | 即座 |

### ファイルサイズ詳細

| データセット | ツリー構造 | 統計 | 設定 | 合計 |
|-------------|----------|------|------|------|
| test.txt (864) | 3,767 KB | 1.76 KB | 0.25 KB | **3.77 MB** |
| rag_survey.txt (1,041) | ~4,500 KB | 3 KB | 0.25 KB | **~4.5 MB** |

---

## 🎓 まとめ

### 本実装の利点（v2.0 完全版）

1. **完全性**: ドキュメント内容も保存し確実な検索 ✅
2. **高速**: 読み込みが即座に完了（< 1秒）⚡
3. **可読**: JSON形式で人間・機械が読める 📖
4. **汎用**: Python以外でも利用可能 🌐
5. **再現性**: 設定パラメータも保存 🔄
6. **保守性**: バージョン管理が容易 📦

### 推奨用途

- ✅ **本番環境へのデプロイ**（最優先）
- ✅ 開発環境でのモデル保存・共有
- ✅ モデルのバージョン管理
- ✅ A/Bテスト用の複数モデル保持
- ✅ バックアップ・ロールバック

### 特徴

- ✅ 完全なドキュメント検索が可能
- ✅ 本番環境で確実に動作
- ✅ 読み込み速度は高速を維持
- ⚠️ サイズは要約のみ版の約19倍（許容範囲内）

### 制限事項

- ⚠️ ファイルサイズは数MB（データセット規模に比例）
- ⚠️ 超大規模データ（100万チャンク以上）では別手法を検討
- ⚠️ 埋め込みモデル変更時は再構築が必要

---

**更新日**: 2025年10月18日  
**バージョン**: 2.0  
**ステータス**: 本番環境対応完了 ✅  
**検証済み**: test.txt（864チャンク）で検索成功（3件取得）


---

##  参考資料

- [README.md](README.md) - プロジェクト概要と使用方法
- [LESSONS_LEARNED_PART2.md](LESSONS_LEARNED_PART2.md) - CHI除外の理由と実験結果
- [raptor_tree_visualization.ipynb](raptor_tree_visualization.ipynb) - 可視化とv2.0テスト
- [raptor_eval.py](raptor_eval.py) - 実装コード（791行、v2.0対応）

---

## ライセンス

MIT License
