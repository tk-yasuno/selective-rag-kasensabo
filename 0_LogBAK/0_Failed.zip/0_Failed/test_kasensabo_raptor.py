"""
河川砂防RAPTOR システム - 簡易テストスクリプト
基本的な動作確認用
"""

from pathlib import Path
from kasensabo_raptor import KasensaboRAPTOR

def main():
    print("=" * 60)
    print("河川砂防RAPTOR システム - 簡易テスト")
    print("=" * 60)
    
    # データディレクトリ
    data_dir = Path(__file__).parent / "data" / "kasensabo_knowledge_base"
    
    if not data_dir.exists():
        print(f"❌ エラー: データディレクトリが見つかりません: {data_dir}")
        return
    
    # RAPTORシステムを初期化（軽量モデル）
    print("\n🚀 RAPTORシステム初期化中...")
    raptor = KasensaboRAPTOR(
        embedding_model_name="sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2",
        max_clusters_per_layer=3,  # 小さくして高速化
        min_cluster_size=2,
        chunk_size=800,
        chunk_overlap=150,
    )
    
    # 文書を読み込み
    print(f"\n📂 文書読み込み中...")
    documents = raptor.load_documents_from_directory(str(data_dir))
    
    if len(documents) == 0:
        print("❌ エラー: 文書が見つかりません")
        return
    
    # 最初の2つの文書のみでテスト（高速化）
    print(f"\n⚡ テスト用に最初の2文書のみ使用")
    test_documents = documents[:2]
    
    # RAPTORツリーを構築
    print(f"\n🔨 RAPTORツリー構築中...")
    raptor.build_raptor_tree(test_documents, max_depth=2)
    
    # FAISSインデックスを構築
    raptor.build_faiss_index()
    
    # 統計情報を表示
    stats = raptor.get_tree_statistics()
    print(f"\n📊 ツリー統計:")
    for key, value in stats.items():
        print(f"   {key}: {value}")
    
    # テストクエリ
    test_queries = [
        "河川の維持管理",
        "技術基準の目的",
        "調査編の内容",
    ]
    
    print(f"\n🔍 テストクエリ実行:")
    for query in test_queries:
        print(f"\n  クエリ: {query}")
        results = raptor.query(query, top_k=3)
        for i, (node_id, score, node) in enumerate(results, 1):
            print(f"    {i}. Score: {score:.4f} | Depth: {node.depth} | {node.text[:50]}...")
    
    # ツリーを保存
    output_path = Path(__file__).parent / "kasensabo_raptor_tree_test.pkl"
    raptor.save_tree(str(output_path))
    
    print(f"\n{'='*60}")
    print("✅ テスト完了")
    print(f"{'='*60}\n")

if __name__ == "__main__":
    main()
